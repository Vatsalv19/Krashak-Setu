import React, { useState } from 'react';
import styled from 'styled-components';

const ForumContainer = styled.div`
  margin-top: 20px;
`;

const CommentBox = styled.div`
  margin-bottom: 20px;
`;

const Forum = () => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    setComments([...comments, newComment]);
    setNewComment('');
  };

  return (
    <ForumContainer>
      <h3>Forum Discussion</h3>
      <form onSubmit={handleCommentSubmit}>
        <textarea
          placeholder="Enter your comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
        />
        <button type="submit">Post Comment</button>
      </form>

      <div>
        {comments.map((comment, index) => (
          <CommentBox key={index}>
            <p>{comment}</p>
          </CommentBox>
        ))}
      </div>
    </ForumContainer>
  );
};

export default Forum;
