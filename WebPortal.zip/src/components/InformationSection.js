import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './InformationSection.css'; // Importing the CSS file

// Information Section Component with Slider
const InformationSection = () => {
  // Slider settings
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    autoplay: true,
    autoplaySpeed: 4000, // Slide every 4 seconds
    arrows: true,
    responsive: [
      {
        breakpoint: 768, // For mobile devices
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1024, // For tablets
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
    ],
  };

  // Return statement
  return (
    <div className="information-section">
      <h2>Key Information for Farmers</h2>
      <Slider {...sliderSettings}>
        <div className="info-block">
          <div className="info-icon">🌾</div>
          <h3>Modern Farming Techniques</h3>
          <p>
            Learn about the latest farming techniques and technology to increase productivity and sustainability.
          </p>
        </div>

        <div className="info-block">
          <div className="info-icon">📊</div>
          <h3>Market Trends</h3>
          <p>
            Stay updated with current market trends to make informed decisions on crop cultivation and sales.
          </p>
        </div>

        <div className="info-block">
          <div className="info-icon">📅</div>
          <h3>Events and Workshops</h3>
          <p>
            Participate in upcoming agricultural events and workshops for networking and skill development.
          </p>
        </div>

        <div className="info-block">
          <div className="info-icon">🌱</div>
          <h3>Sustainable Practices</h3>
          <p>
            Discover sustainable farming practices that help conserve resources and improve soil health.
          </p>
        </div>

        <div className="info-block">
          <div className="info-icon">💧</div>
          <h3>Water Management</h3>
          <p>
            Effective irrigation and water management techniques to maximize crop yield with minimal water usage.
          </p>
        </div>

        <div className="info-block">
          <div className="info-icon">🔍</div>
          <h3>Crop Disease Identification</h3>
          <p>
            Tips for identifying common crop diseases early and implementing preventive measures.
          </p>
        </div>
      </Slider>
    </div>
  );
};

export default InformationSection;
