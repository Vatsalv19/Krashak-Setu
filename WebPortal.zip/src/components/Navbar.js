import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'; 
import 'bootstrap/dist/css/bootstrap.min.css'; 
import './Navbar.css'; // Import custom CSS for Navbar

const Navbar = () => {
  const [scrolling, setScrolling] = useState(false);
  const [sticky, setSticky] = useState(true); // Sticky navbar state

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolling(true); // Change background color when scrolled
      } else {
        setScrolling(false);
      }

      // Get footer element and check if it's in the viewport
      const footer = document.getElementById('footer');
      if (footer) {
        const footerPosition = footer.getBoundingClientRect().top;
        // If the footer is in view, stop the navbar from sticking
        if (footerPosition <= window.innerHeight) {
          setSticky(false);
        } else {
          setSticky(true);
        }
      }
    };

    // Attach the scroll event listener
    window.addEventListener('scroll', handleScroll);

    // Cleanup the event listener on unmount
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`navbar navbar-expand-lg navbar-dark custom-navbar ${scrolling ? 'bg-dark' : ''} ${sticky ? 'sticky-active' : ''}`}
    >
      <div className="container-fluid">
        {/* Brand */}
        <Link className="navbar-brand" to="/">Krashak Setu</Link>

     

        {/* Login Button */}
        <Link to="/emitra-login" className="btn btn-outline-light ms-auto custom-login-btn">
          <i className="fas fa-sign-in-alt"></i> Login Krashak Setu
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
