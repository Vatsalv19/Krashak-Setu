import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./Partners.css"; // Custom styles

const PartnerCarousel = () => {
  const settings = {
    dots: false, // No dots for navigation
    infinite: true, // Loop the slides
    speed: 1000, // Transition speed
    slidesToShow: 5, // Number of logos shown at once
    slidesToScroll: 1, // Scroll one logo at a time
    autoplay: true, // Enable autoplay
    autoplaySpeed: 2000, // Time between slides
    cssEase: "linear", // Smooth animation
    pauseOnHover: false, // Don't pause on hover
    responsive: [
      {
        breakpoint: 1200, // Large screens
        settings: { slidesToShow: 4 },
      },
      {
        breakpoint: 992, // Medium screens (tablets)
        settings: { slidesToShow: 3 },
      },
      {
        breakpoint: 768, // Small screens (phones)
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 576, // Extra small screens
        settings: { slidesToShow: 1 },
      },
    ],
  };

  const partners = [
    { logo: "/images/logo1.png" },
    { logo: "/images/logo2.png" },
    { logo: "/images/logo3.png" },
    { logo: "/images/logo4.png" },
 
  ];
  

  return (
    <div className="container my-5">
      <h2 className="text-center mb-4">Our Partners</h2>
      <Slider {...settings}>
        {partners.map((partner, index) => (
          <div key={index} className="d-flex justify-content-center">
            <div className="partner-logo">
              <img
                src={partner.logo}
                alt={`Partner Logo ${index + 1}`}
                style={{
                  width: "100%",  // Adjust logo size
                  height: "auto", // Maintain aspect ratio
                  objectFit: "contain", // Ensure logos don't get stretched
                }}
              />
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default PartnerCarousel;
