import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const Navbar = styled.nav`
  display: flex;
  justify-content: space-between;
  background-color: #2ecc71;
  padding: 15px;
`;

const NavLinks = styled.div`
  a {
    margin-right: 15px;
    color: white;
    font-weight: bold;
  }
`;

const Header = () => {
  return (
    <Navbar>
      <h1>Farmer's Portal</h1>
      <NavLinks>
        <Link to="/">Home</Link>
        <Link to="/login">E-mitra Login</Link>
        <Link to="/resources">Educational Resources</Link>
        <Link to="/forum">Community Forum</Link>
        <Link to="/contact">Contact Us</Link>
      </NavLinks>
    </Navbar>
  );
};

export default Header;
