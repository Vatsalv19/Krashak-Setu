import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Bootstrap CSS import
import "./Testimonial.css"; // Import the Testimonial-specific CSS

const Testimonial = ({ name, photo, words }) => {
  return (
    <div className="testimonial-section d-flex align-items-center justify-content-center flex-column text-center my-5">
      <div className="image-container mb-4">
        <img
          src={photo}
          alt={name}
          className="rounded-circle border border-success"
          style={{
            width: "180px",
            height: "180px",
            objectFit: "cover",
            borderWidth: "4px",
          }}
        />
      </div>
      <h4 className="text-success mb-3">{name}</h4>
      <p className="text-muted" style={{ fontSize: "18px", maxWidth: "600px" }}>
        {words}
      </p>
    </div>
  );
};

const Testimonials = () => {
  const testimonialData = [
    {
        name: "Narendra Modi",
        photo: "https://www.pmindia.gov.in/wp-content/uploads/2022/12/twitter_3.jpg",
        words: "Krashak Setu is a revolutionary initiative empowering farmers across India.",
      },
      
      
    {
      name: "Shivraj Singh Chouhan",
      photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_tPfcnIsStIgDtmLSzA0hhiUqFBEbDSj-cg&s",
      words: "A wonderful step towards strengthening rural development and agriculture.",
    },
    {
      name: "Bhajan Lal Sharma",
      photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwExdNQpxAYUV4XkYJCehjy6kMKvOUv1XYIA&s",
      words: "This initiative has truly transformed lives in rural India.",
    },
  ];

  return (
    <section className="testimonial-container">
      <div className="container">
        <div className="text-center mb-5">
          <h2 className="fw-bold text-success">What Leaders Say About Krashak Setu</h2>
          <p className="text-muted">Our initiative has received accolades from national and state leaders.</p>
        </div>
        {testimonialData.map((testimonial, index) => (
          <Testimonial
            key={index}
            name={testimonial.name}
            photo={testimonial.photo}
            words={testimonial.words}
          />
        ))}
      </div>
    </section>
  );
};

export default Testimonials;
