import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

// Styled-components for the FAQ section
const FaqSection = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 40px auto;
  padding: 20px;
  text-align: center;
  border-radius: 8px;
  background-color: #f9f9f9;
`;

const FaqTitle = styled.h2`
  font-size: 2rem;
  color: #333;
  margin-bottom: 15px;
`;

const FaqList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 800px;
  margin: 0 auto;
  text-align: left;
`;

const FaqItem = styled.div`
  background-color: #fff;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

const FaqQuestion = styled.h4`
  font-size: 1.2rem;
  color: #333;
`;

const FaqAnswer = styled.p`
  font-size: 1rem;
  color: #555;
`;

const FaQ = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Toggle functions for menu and dropdown
  const toggleMenu = () => setMenuOpen(!menuOpen);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  // Handle scrolling behavior
  const handleScroll = () => {
    setScrolled(window.scrollY > 50);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
   
    
      <FaqSection>
        <FaqTitle>Frequently Asked Questions</FaqTitle>
        <FaqList>
          <FaqItem>
            <FaqQuestion>What is E-Mitra?</FaqQuestion>
            <FaqAnswer>E-Mitra is an online platform designed to assist farmers by providing them with resources, tools, and community support.</FaqAnswer>
          </FaqItem>
          <FaqItem>
            <FaqQuestion>How do I register as a farmer?</FaqQuestion>
            <FaqAnswer>To register as a farmer, click on the "Create Account" card and fill in the registration form with your details.</FaqAnswer>
          </FaqItem>
          <FaqItem>
            <FaqQuestion>How can I access government services through E-Mitra?</FaqQuestion>
            <FaqAnswer>E-Mitra provides easy access to government services such as the PM Kisan Scheme and other agricultural resources. You can explore these services on our platform.</FaqAnswer>
          </FaqItem>
          <FaqItem>
            <FaqQuestion>Is there a mobile app for E-Mitra?</FaqQuestion>
            <FaqAnswer>Currently, E-Mitra is available as a web platform. However, we are working on expanding the services to a mobile app soon.</FaqAnswer>
          </FaqItem>
          <FaqItem>
            <FaqQuestion>How can I get help if I encounter an issue?</FaqQuestion>
            <FaqAnswer>If you encounter any issues, you can reach out to our support team through the "Contact Us" page on the website.</FaqAnswer>
          </FaqItem>
        </FaqList>
      </FaqSection>
   
  );
};

export default FaQ;
