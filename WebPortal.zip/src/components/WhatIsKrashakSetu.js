import React from 'react';

const WhatIsKrashakSetu = () => {
  return (
    <div
    style={{
        backgroundColor: '#f7f3e9', // Soft beige to represent natural soil and simplicity.
        color: '#2f4f1e', // Rich green to evoke the lushness of crops and nature.
        fontFamily: "'Poppins', sans-serif", // A clean and approachable font with a modern yet rustic vibe.
        padding: '2rem',
        borderRadius: '12px', // Slightly larger radius to give a soft, natural look.
        boxShadow: '0 6px 12px rgba(0, 0, 0, 0.15)', // Subtle shadow for a grounded, professional feel.
        width: '90%',
        maxWidth: '1700px',
        margin: '2rem auto',
        lineHeight: '1.8',
        border: '2px solid #d4cbb6', // Adds a frame-like appearance resembling wooden farm fences.
        backgroundImage: 'url("https://example.com/texture.png")', // Optional: Add a light farm-related texture or subtle pattern.
        backgroundSize: 'cover',
        backgroundBlendMode: 'soft-light',
      }}
      
    >
      <h2
        style={{
          fontSize: '2.5rem',
          fontWeight: 'bold',
          marginBottom: '1rem',
          textAlign: 'center',
          color: '#2e5a1c',
        }}
      >
        What is Krashak Setu?
      </h2>
      <p style={{ marginBottom: '1rem', fontSize: '1.2rem' }}>
        <strong>Krashak Setu</strong> is an innovative initiative aimed at empowering farmers and enhancing
        agricultural practices by bridging the gap between technology, knowledge, and rural development. 
        The platform serves as a dynamic hub for farmers, agricultural experts, and stakeholders to collaborate 
        on solving real-world challenges faced in rural areas and the agricultural sector.
      </p>
      <p style={{ marginBottom: '1rem', fontSize: '1.2rem' }}>
        Launched with the goal of fostering innovation and practical solutions in agriculture, Krashak Setu
        provides opportunities to share expertise, adopt modern farming techniques, and implement sustainable
        agricultural practices. By encouraging critical thinking and collaboration, Krashak Setu aims to uplift
        rural communities and drive socio-economic development.
      </p>
      <p style={{ marginBottom: '1.5rem', fontSize: '1.2rem' }}>
        Since its inception, Krashak Setu has successfully promoted out-of-the-box thinking among rural youth 
        and farmers. Its initiatives focus on knowledge sharing, capacity building, and connecting farmers with 
        industry experts, government agencies, and academic institutions, making agriculture more efficient and impactful.
      </p>
      <div
        style={{
          marginTop: '1.5rem',
          textAlign: 'center',
        }}
      >
        <button
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: '#4caf50',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '1rem',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
          }}
        >
          Learn More
        </button>
      </div>
    </div>
  );
};

export default WhatIsKrashakSetu;
