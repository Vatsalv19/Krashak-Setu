import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./CarouselSection.css";

const Carousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 900,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: true,
    autoplay: true, // Enables autoplay
    autoplaySpeed: 3000, // Transition every 3 seconds
    pauseOnHover: true, // Pauses autoplay on hover
    cssEase: "linear", // Smooth transitions
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2, slidesToScroll: 1 },
      },
      {
        breakpoint: 768,
        settings: { slidesToShow: 1, slidesToScroll: 1 },
      },
    ],
  };

  const cards = [
    {
      title: "SUSTAINABLE FARMING",
      description: "Promoting eco-friendly farming practices for better yields.",
      icon: "🌾",
      color: "#88C057", // Green for agriculture
    },
    {
      title: "RURAL DEVELOPMENT",
      description: "Building essential infrastructure for rural growth and self-reliance.",
      icon: "🏡",
      color: "#FFA500", // Orange for rural themes
    },
    {
      title: "FARMER EMPOWERMENT",
      description: "Empowering farmers with tools and technology to succeed.",
      icon: "👩‍🌾",
      color: "#2E86C1", // Blue for technology-driven growth
    },
    {
      title: "WATER CONSERVATION",
      description: "Efficient water usage for sustainable farming.",
      icon: "💧",
      color: "#007BFF", // Blue for water conservation
    },
    {
      title: "AGRI-TECH ADVANCEMENTS",
      description: "Leveraging technology to boost agricultural productivity.",
      icon: "📱",
      color: "#28A745", // Green for tech innovation
    },
  ];

  return (
    <div className="carousel-container">
      <h2 className="carousel-title">KRASHAK SETU IMPACT</h2>
      <p className="carousel-subtitle">
        Empowering Agriculture, Farmers, and Rural Development
      </p>
      <Slider {...settings}>
        {cards.map((card, index) => (
          <div key={index} className="carousel-card">
            <div
              className="card-content"
              style={{
                backgroundColor: card.color,
                borderRadius: "10px",
                padding: "20px",
                color: "#fff",
                textAlign: "center",
              }}
            >
              <div className="card-icon" style={{ fontSize: "2.5rem" }}>
                {card.icon}
              </div>
              <h3 className="card-title" style={{ marginTop: "10px" }}>
                {card.title}
              </h3>
              <p className="card-description" style={{ marginTop: "10px" }}>
                {card.description}
              </p>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Carousel;
