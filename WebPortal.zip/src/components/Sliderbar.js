import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styled, { keyframes } from 'styled-components';
import { FiHome, FiUser, FiShoppingCart, FiBook, FiLogOut, FiMenu } from 'react-icons/fi';

// Slide-in animation for Sidebar
const slideIn = keyframes`
  from {
    transform: translateX(-100%);
  }
  to {
    transform: translateX(0);
  }
`;

// Styled Components for Sidebar
const Sidebar = styled.div`
  width: 260px;
  background-color: #2c3e50;
  color: white;
  padding: 20px;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  z-index: 100;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.3);
  animation: ${slideIn} 0.5s ease-out;
  transition: transform 0.3s ease-in-out;

  h2 {
    text-align: center;
    font-size: 2.2rem;
    margin-bottom: 30px;
    font-weight: bold;
    color: #f39c12;
    text-transform: uppercase;
  }

  @media (max-width: 768px) {
    width: auto;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    padding: 15px;
    transform: translateX(${(props) => (props.open ? '0' : '-100%')});
  }
`;

const SidebarItem = styled.div`
  display: flex;
  align-items: center;
  margin: 20px 0;
  cursor: pointer;
  padding: 12px;
  border-radius: 10px;
  transition: background 0.3s ease-in-out, transform 0.2s ease;

  &:hover {
    background-color: #34495e;
    transform: scale(1.05);
  }
`;

const SidebarIcon = styled.div`
  font-size: 1.8rem;
  margin-right: 15px;
`;

const SidebarLink = styled(Link)`
  color: white;
  text-decoration: none;
  font-size: 1.2rem;
  font-weight: 500;
  letter-spacing: 0.5px;

  &:hover {
    color: #f39c12;
  }
`;

// Hamburger Menu for small screens
const HamburgerMenu = styled.div`
  display: none;
  font-size: 2.2rem;
  cursor: pointer;
  color: red;

  @media (max-width: 768px) {
    display: block;
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 101;
  }
`;

const Siderbar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <>
      {/* Hamburger Menu for small screens */}
      <HamburgerMenu onClick={toggleSidebar}>
        <FiMenu />
      </HamburgerMenu>

      {/* Sidebar Component */}
      <Sidebar open={isSidebarOpen}>
        <h2>Farmers Portal</h2>
        <SidebarItem>
          <SidebarIcon>
            <FiHome />
          </SidebarIcon>
          <SidebarLink to="/FarmerDashboard">Home</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiUser />
          </SidebarIcon>
          <SidebarLink to="/profile">Profile</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiShoppingCart />
          </SidebarIcon>
          <SidebarLink to="/products">Listed Crops</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiBook />
          </SidebarIcon>
          <SidebarLink to="/TopProduct">Trending in Market</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiLogOut />
          </SidebarIcon>
          <SidebarLink to="/logout">Log Out</SidebarLink>
        </SidebarItem>
      </Sidebar>
    </>
  );
};

export default Siderbar;
