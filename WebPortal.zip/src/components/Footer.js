import React from "react";
import "./Footer.css"; // Add custom styles

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="row">
          {/* Logo and Social Icons */}
          <div className="col-md-3">
            <div className="footer-logo">
              <img
                src="/path-to-logo/logo.png"
                alt="FarmAnchor Logo"
                className="footer-logo-img"
              />
              <h5>Krashak Setu</h5>
            </div>
            <div className="social-icons">
              <a href="#" className="social-link">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="social-link">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="social-link">
                <i className="fab fa-linkedin"></i>
              </a>
            </div>
          </div>

          {/* Company Section */}
          <div className="col-md-2">
            <h6 className="footer-title">Company</h6>
            <ul className="footer-list">
              <li>
                <a href="#" className="footer-link">About us</a>
              </li>
              <li>
                <a href="#" className="footer-link">Careers</a>
              </li>
            </ul>
          </div>

          {/* Solution Section */}
          <div className="col-md-3">
            <h6 className="footer-title">Solution</h6>
            <ul className="footer-list">
              <li>
                <a href="#" className="footer-link">Area Yield Index Insurance</a>
              </li>
              <li>
                <a href="#" className="footer-link">Hybrid Index Insurance</a>
              </li>
              <li>
                <a href="#" className="footer-link">Livestock Insurance</a>
              </li>
              <li>
                <a href="#" className="footer-link">Smart Farming</a>
              </li>
              <li>
                <a href="#" className="footer-link">Disaster Risk Funding</a>
              </li>
            </ul>
          </div>

          {/* Resources Section */}
          <div className="col-md-2">
            <h6 className="footer-title">Resources</h6>
            <ul className="footer-list">
              <li>
                <a href="#" className="footer-link">Blog</a>
              </li>
              <li>
                <a href="#" className="footer-link">Case Studies</a>
              </li>
              <li>
                <a href="#" className="footer-link">Press</a>
              </li>
              <li>
                <a href="#" className="footer-link">FAQs</a>
              </li>
              <li>
                <a href="#" className="footer-link">Support</a>
              </li>
            </ul>
          </div>

          {/* Contact Us Section */}
          <div className="col-md-2">
            <h6 className="footer-title">Contact Us</h6>
            <ul className="footer-list">
              <li>info@farmanchor.com</li>
              <li>+24 810 567 5624</li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom">
          <p>© 2024 FarmAnchor. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
