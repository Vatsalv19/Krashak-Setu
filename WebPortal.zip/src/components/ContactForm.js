import React from 'react';

const ContactForm = () => {
  return (
    <form>
      <label>Name:</label>
      <input type="text" placeholder="Enter your name" />
      
      <label>Email:</label>
      <input type="email" placeholder="Enter your email" />
      
      <label>Message:</label>
      <textarea placeholder="Your message"></textarea>
      
      <button type="submit">Submit</button>
    </form>
  );
};

export default ContactForm;
