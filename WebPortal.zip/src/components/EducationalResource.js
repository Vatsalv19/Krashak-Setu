import React from 'react';
import styled from 'styled-components';

const ResourceCard = styled.div`
  background-color: #ecf0f1;
  padding: 15px;
  margin: 10px 0;
  border-radius: 5px;
`;

const EducationalResource = ({ title, description }) => {
  return (
    <ResourceCard>
      <h3>{title}</h3>
      <p>{description}</p>
    </ResourceCard>
  );
};

export default EducationalResource;
