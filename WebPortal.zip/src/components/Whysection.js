import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap-icons/font/bootstrap-icons.css";

const WhySection = () => {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4 text-success">
        Why Join Us
      </h2>
      <div className="row row-cols-1 row-cols-md-4 g-4">
        {/* Card 1 */}
        <div className="col">
          <div className="card border-0 text-center h-100">
            <div className="card-body">
              <i className="bi bi-bar-chart-fill text-success fs-1 mb-3"></i>
              <h5 className="card-title text-success">
                Data-Driven Insights
              </h5>
              <p className="card-text">
                Get access to valuable data insights to improve farming productivity.
              </p>
            </div>
          </div>
        </div>

        {/* Card 2 */}
        <div className="col">
          <div className="card border-0 text-center h-100">
            <div className="card-body">
              <i className="bi bi-people-fill text-success fs-1 mb-3"></i>
              <h5 className="card-title text-success">
                Community Support
              </h5>
              <p className="card-text">
                Join a vibrant community of farmers and agricultural experts.
              </p>
            </div>
          </div>
        </div>

        {/* Card 3 */}
        <div className="col">
          <div className="card border-0 text-center h-100">
            <div className="card-body">
              <i className="bi bi-tree text-success fs-1 mb-3"></i> {/* Leaf icon */}
              <h5 className="card-title text-success">
                Sustainable Farming
              </h5>
              <p className="card-text">
                Learn innovative techniques for sustainable and eco-friendly farming.
              </p>
            </div>
          </div>
        </div>

        {/* Card 4 */}
        <div className="col">
          <div className="card border-0 text-center h-100">
            <div className="card-body">
              <i className="bi bi-globe text-success fs-1 mb-3"></i>
              <h5 className="card-title text-success">
                Global Opportunities
              </h5>
              <p className="card-text">
                Expand your agricultural reach through international collaborations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhySection;
