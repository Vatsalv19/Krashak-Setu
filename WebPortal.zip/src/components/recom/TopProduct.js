/* global Chart */
import React, { useEffect, useRef, useState } from 'react';
import Sliderbar from '../Sliderbar';
const TopProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const chartRef = useRef(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("http://localhost:3000/top-products");
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setProducts(data.slice(0, 5));
      } catch (err) {
        console.error("Fetch error:", err.message);
        setError("Failed to fetch data.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    if (products.length > 0 && chartRef.current) {
      const ctx = chartRef.current.getContext("2d");

      // Destroy existing chart instance if any
      if (window.myBarChart) {
        window.myBarChart.destroy();

      }

      // Create a new chart instance
      window.myBarChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: products.map(product => product.cropName),
          datasets: [
            {
              label: 'Sales quantity',
              data: products.map(product => product.quantity),
              backgroundColor: 'rgba(75, 192, 192, 0.5)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Recommended Products Sales' },
          },
        },
      });
    }
  }, [products]);

  if (loading) {
    return <p>Loading recommended products...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }
  <Sliderbar/>
  return (
    <div style={{ padding: "20px", maxWidth: "800px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Recommended Products</h2>


      <div
        style={{
          padding: "20px",
          border: "1px solid #ddd",
          borderRadius: "8px",
          boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
          marginBottom: "20px",
          backgroundColor: "#fff",
        }}
      >
        <Sliderbar/>
        <canvas ref={chartRef} style={{ width: "100%", height: "200px" }}></canvas>
      </div>

      {/* Product List */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px",
        }}
      >
        {products.map((product, index) => (
          <div
            key={index}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "15px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              backgroundColor: "#f9f9f9",
              boxShadow: "0 1px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            <div style={{ fontWeight: "bold" }}>#{index + 1}</div>
            <div style={{ flex: 1, marginLeft: "10px" }}>
              <p style={{ margin: "0", fontWeight: "bold" }}>Product: {product.cropName}</p>
              <p style={{ margin: "0", color: "#555" }}>Sales: {product.quantity}</p>
            </div>
            <div
         
            >
             
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopProducts;
