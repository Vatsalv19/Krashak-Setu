import React, { useState, useEffect } from "react";
import styled from "styled-components";

const PredictiveProduct = () => {
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch predictions on component mount
  useEffect(() => {
    const fetchPredictions = async () => {
      try {
        const response = await fetch("http://localhost:3000/predict-products"); // Your API endpoint
        if (!response.ok) {
          throw new Error("Failed to fetch predictions");
        }
        const data = await response.json();
        console.log("API Response:", data); // Log the API response to inspect the data
        setPredictions(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPredictions();
  }, []);

  // Calculate chance of trending product based on predicted quantity
  const calculateTrendingChance = (predictedQuantity) => {
    const maxQuantity = Math.max(...predictions.map((pred) => pred.predictedQuantity)); // Get max predicted quantity
    const chance = (predictedQuantity / maxQuantity) * 100; // Calculate percentage chance
    return Math.min(chance, 95).toFixed(2); // Ensure the chance does not exceed 95%
  };
  

  if (loading) return <LoadingMessage>Loading predictions...</LoadingMessage>;
  if (error) return <ErrorMessage>{error}</ErrorMessage>;

  return (
    <Container>
      <Header>Predicted Top-Selling Products</Header>
      <Table>
        <thead>
          <tr>
            <Th>Crop Name</Th>
            <Th>Predicted Quantity</Th>
            <Th>Chances of next Trending</Th>
          </tr>
        </thead>
        <tbody>
          {predictions.length > 0 ? (
            predictions.map((prediction) => (
              <tr key={prediction.cropName}>
                <Td>{prediction.cropName}</Td>
                <Td>
                  {prediction.predictedQuantity
                    ? prediction.predictedQuantity.toFixed(2)
                    : "No data available"}
                </Td>
                <Td>
                  {prediction.predictedQuantity
                    ? `${calculateTrendingChance(prediction.predictedQuantity)}%`
                    : "No data available"}
                </Td>
              </tr>
            ))
          ) : (
            <tr>
              <Td colSpan="3">No predictions available</Td>
            </tr>
          )}
        </tbody>
      </Table>

      <SummarySection>
        <SummaryTitle>NOTE</SummaryTitle>
        <SummaryText>
        Please note that the data presented here is based on predictive models and may not always be accurate. The predictions are subject to change as new data is collected, and market conditions evolve. We recommend using this information as a guide and staying updated with the latest trends.
        </SummaryText>
      </SummarySection>
    </Container>
    
  );
};

const SummarySection = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 80px auto; /* Reduced margin for better alignment */
  padding: 30px;
  text-align: center;
  border-radius: 10px;
  background-color: #fffbf2; /* Soft yellow background for emphasis */
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
  border-left: 5px solid #e67e22; /* Orange left border for distinction */
`;

const SummaryTitle = styled.h2`
  font-size: 2.2rem; /* Slightly larger font for the title */
  color: #e67e22; /* Orange color for the title to match the border */
  margin-bottom: 15px;
  font-weight: 700; /* Make title bold to emphasize its importance */
`;

const SummaryText = styled.p`
  font-size: 1.1rem;
  color: #555;
  line-height: 1.8; /* Increased line height for readability */
  max-width: 900px;
  margin: 0 auto;
  font-weight: 500;
`;




const Container = styled.div`
  padding: 20px;
  background-color: #f9f9f9;
  margin: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  opacity: 0;
  animation: fadeIn 0.9s forwards; /* Fade-in effect */
  
  /* Smooth shadow on hover */
  &:hover {
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
  }

  @keyframes fadeIn {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
`;

const Header = styled.h2`
  font-size: 2rem;
  color: #333;
  margin-bottom: 20px;
  text-align: center;
  opacity: 0;
  animation: fadeInHeader 0.6s 0.3s forwards; /* Delay for header fade-in */
  
  @keyframes fadeInHeader {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  opacity: 0;
  animation: fadeInTable 0.6s 0.5s forwards; /* Delay for table fade-in */
  
  @keyframes fadeInTable {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
`;

const Th = styled.th`
  padding: 10px;
  text-align: left;
  background-color: #2980b9;
  color: #fff;
  transition: background-color 0.3s ease-in-out;
  
  &:hover {
    background-color: #3498db;
  }
`;

const Td = styled.td`
  padding: 10px;
  text-align: left;
  border-top: 1px solid #ddd;
  transition: background-color 0.3s ease-in-out;

  &:hover {
    background-color: #ecf0f1;
  }
`;

const LoadingMessage = styled.p`
  text-align: center;
  font-size: 1.5rem;
  color: #333;
  opacity: 0;
  animation: fadeIn 0.6s forwards;
`;

const ErrorMessage = styled.p`
  text-align: center;
  font-size: 1.5rem;
  color: red;
  opacity: 0;
  animation: fadeIn 0.6s forwards;
`;


export default PredictiveProduct;
