const express = require("express");
const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs } = require("firebase/firestore");
const { LinearRegression } = require("simple-statistics"); // Simple library for linear regression

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyC1mU4cGi0kxGmAjzvA-zrkGVbXqfMQBtQ",
  authDomain: "krashak-setu-testing.firebaseapp.com",
  projectId: "krashak-setu-testing",
  storageBucket: "krashak-setu-testing.appspot.com",
  messagingSenderId: "730432132265",
  appId: "1:730432132265:web:5e54bcd42e570cd71705b8",
};

// Initialize Firebase
const appFirebase = initializeApp(firebaseConfig);
const db = getFirestore(appFirebase);

const app = express();
app.use(express.json());

// Custom CORS Middleware
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // Allow all origins
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  ); // Allowed methods
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type, Authorization"
  ); // Allowed headers
  next();
});

// API Endpoint: Get Top-Selling Products
app.get("/top-products", async (req, res) => {
  try {
    const ordersCollection = collection(db, "orders");
    const ordersSnapshot = await getDocs(ordersCollection);

    if (ordersSnapshot.empty) {
      return res.status(404).json({ error: "No orders found." });
    }

    const salesCount = {};

    ordersSnapshot.forEach((doc) => {
      const userOrders = doc.data().orders;
      if (Array.isArray(userOrders)) {
        userOrders.forEach(({ cropName, quantity }) => {
          if (cropName && quantity && !isNaN(quantity)) {
            salesCount[cropName] = (salesCount[cropName] || 0) + quantity;
          }
        });
      }
    });

    const sortedProducts = Object.entries(salesCount)
      .sort(([, qtyA], [, qtyB]) => qtyB - qtyA)
      .map(([cropName, quantity]) => ({ cropName, quantity }));

    res.status(200).json(sortedProducts);
  } catch (error) {
    console.error("Error fetching top products:", error);
    res.status(500).json({ error: "Failed to fetch top-selling products." });
  }
});


//----------------------------Prediction API----------------------------------------------------------------------------
app.get("/predict-products", async (req, res) => {
  try {
    const ordersCollection = collection(db, "orders"); // Reference to the orders collection in Firestore
    const ordersSnapshot = await getDocs(ordersCollection); // Fetch all orders from the orders collection

    if (ordersSnapshot.empty) {
      return res.status(404).json({ error: "No orders found." }); // Handle empty orders collection
    }

    const salesData = {}; // Structure to store sales data for each crop

    // Collect sales data (ignoring date, just using cropName and quantity)
    ordersSnapshot.forEach((doc) => {
      const userOrders = doc.data().orders; // Assuming each document has an 'orders' field
      if (Array.isArray(userOrders)) {
        userOrders.forEach(({ cropName, quantity }) => {
          if (cropName && quantity && !isNaN(quantity)) {
            // Aggregate the quantities for each crop
            salesData[cropName] = (salesData[cropName] || 0) + quantity;
          }
        });
      }
    });

    const predictions = []; // Array to store the predicted sales for each crop

    // Apply a simple prediction model (e.g., linear regression based on sales quantities)
    for (const [cropName, totalQuantity] of Object.entries(salesData)) {
      // For simplicity, we just predict future quantities based on the existing sales (here we use the total quantity)
      // A more complex model would involve time-series data, but for simplicity we use the total quantity as a proxy for prediction.

      // Example prediction logic: predict a 10% increase in future sales
      const predictedQuantity = totalQuantity * 1.1; // Predicted future quantity

      predictions.push({
        cropName,
        predictedQuantity,
      });
    }

    // Send predicted data as response
    res.status(200).json(predictions);
  } catch (error) {
    console.error("Error predicting products:", error);
    res.status(500).json({ error: "Failed to predict products." }); // Handle errors gracefully
  }
});
//--------------------------------------------------------------------------

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
