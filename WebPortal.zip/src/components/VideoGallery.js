import React from 'react';
import styled from 'styled-components';

const GalleryContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-top: 20px;
`;

const Video = styled.div`
  width: 300px;
  height: 200px;
  background-color: #e1e1e1;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const VideoGallery = () => {
  return (
    <GalleryContainer>
      <Video>Video 1</Video>
      <Video>Video 2</Video>
      <Video>Video 3</Video>
    </GalleryContainer>
  );
};

export default VideoGallery;
