import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home'; // Home component containing Card navigation
import LoginPage from './pages/LoginPage'; // Login component
import EMitraLogin from './pages/EMitraLogin'; // E-Mitra Login component
import GovernmentServicesLogin from './pages/GovernmentServicesLogin'; // Government Services Login component
import ResourcesPage from './pages/ResourcesPage'; // Resources Page component
import ForumPage from './pages/ForumPage'; // Forum Page component
import ContactPage from './pages/ContactPage'; // Contact Page component
import EmitraPage from './pages/EmitraPage';
import FarmerLogin from './pages/FarmerLogin';
import FarmerDashboard from './pages/FarmerDashboard';
import ProfilePage from './pages/ProfilePage'; // Import ProfilePage component
import { UserProvider } from './pages/UserContext'; // Import UserProvider
import AddProductPage from './pages/AddProductPage';
import ProductListPage from './pages/ProductListPage';
import FarmerRegistrationForm from './pages/FarmerRegistrationForm';
import 'bootstrap/dist/css/bootstrap.min.css';
import OrdersPage from './pages/OrdersPage';
import TopProduct from './components/recom/TopProduct';
import FaQ from './components/FaQ';
import PridictiveProduct from './components/recom/PridictiveProduct';
function App() {
  return (
    <UserProvider>
    
      <Router>
        {/* Define the app's main routing structure */}
        <Routes>
          <Route path="/" element={<Home />} /> {/* Main Home page */}
          <Route path="/login-portal" element={<LoginPage />} /> {/* General Login page */}
          <Route path="/emitra-login" element={<EMitraLogin />} /> {/* E-Mitra Login */}
          <Route path="/gov-services-login" element={<GovernmentServicesLogin />} /> {/* Government Services Login */}
          <Route path="/resources" element={<ResourcesPage />} /> {/* Resources Page */}
          <Route path="/forum" element={<ForumPage />} /> {/* Forum Page */}
          <Route path="/contact" element={<ContactPage />} /> {/* Contact Page */}
          <Route path="/EmitraPage" element={<EmitraPage />} />
          <Route path="/FarmerLogin" element={<FarmerLogin />} />
          <Route path="/FarmerDashboard" element={<FarmerDashboard />} />
          <Route path="/profile" element={<ProfilePage />} /> {/* Profile page */}
          <Route path="/addproduct" element={<AddProductPage/>} />
          <Route path="/products" element={<ProductListPage />} />
          <Route path="/FarmerRegistrationForm" element={<FarmerRegistrationForm  />} />
          <Route path="/OrdersPage" element={<OrdersPage  />} />
          <Route path="/TopProduct" element={<TopProduct  />} />
          <Route path="/PridictiveProduct" element={<PridictiveProduct/>} />
          <Route path="/FaQ" element={<FaQ />} />
        </Routes>
      </Router>
    </UserProvider>
   
  );
  
}

export default App;
