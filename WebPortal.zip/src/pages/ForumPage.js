import React from 'react';
import Forum from '../components/Forum';
import styled from 'styled-components';

const Container = styled.div`
  padding: 20px;
`;

const ForumPage = () => {
  return (
    <Container>
      <h2>Community Forum</h2>
      <p>Join the discussion and share your experiences with fellow farmers.</p>
      <Forum />
    </Container>
  );
};

export default ForumPage;
