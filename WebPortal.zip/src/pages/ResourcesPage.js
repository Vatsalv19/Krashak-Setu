import React from 'react';
import EducationalResource from '../components/EducationalResource';
import styled from 'styled-components';

const Container = styled.div`
  padding: 20px;
`;

const ResourcesPage = () => {
  return (
    <Container>
      <h2>Educational Resources</h2>
      <p>Explore articles, guides, and resources to enhance your farming practices.</p>
      <EducationalResource title="Organic Farming" description="A complete guide on organic farming." />
      <EducationalResource title="Pest Management" description="Learn about effective pest control techniques." />
      <EducationalResource title="Water Conservation" description="Tips on conserving water in agriculture." />
    </Container>
  );
};

export default ResourcesPage;
