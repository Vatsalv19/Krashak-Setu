import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth } from './firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import Cookies from 'js-cookie';

const UserContext = createContext();

export const useUser = () => useContext(UserContext);

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // On component mount, check if there's any user stored in the cookie
  useEffect(() => {
    const storedAadhar = Cookies.get('aadhar'); // Retrieve Aadhar from cookies
    console.log('Stored Aadhar from Cookies:', storedAadhar);  // Debugging
    if (storedAadhar) {
      setUser({ aadhar: storedAadhar });
    }
  }, []);

  // Login function using Firebase Authentication
  const login = async (username, password) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, username, password);
      const currentUser = userCredential.user;

      // Fetch Aadhar from Firestore or from custom user properties
      const aadhar = currentUser.displayName || 'No Aadhar'; // Replace with actual logic for Aadhar retrieval

      console.log('Aadhar after login:', aadhar);  // Debugging

      // Store the Aadhar in a cookie for 7 days
      Cookies.set('aadhar', aadhar, { expires: 7 }); // expires in 7 days
      console.log('Aadhar stored in cookie:', Cookies.get('aadhar'));  // Debugging

      // Set user state
      setUser({ aadhar });

      alert('Login Successful!');
      window.location.href = '/FarmerDashboard'; // Redirect after successful login
    } catch (error) {
      alert(`Login Failed: ${error.message}`);
    }
  };

  // Logout function
  const logout = async () => {
    try {
      await auth.signOut();
      setUser(null);
      Cookies.remove('aadhar'); // Remove Aadhar from cookies on logout
      window.location.href = '/'; // Redirect to homepage after logout
    } catch (error) {
      alert(`Logout Failed: ${error.message}`);
    }
  };

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
};
