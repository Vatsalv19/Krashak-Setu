import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { collection, getDocs, doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from './firebase2'; // Ensure this is the correct import for Firestore

// Styled Components
const OrdersContainer = styled.div`
  padding: 40px;
  font-family: Arial, sans-serif;
`;

const Header = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
`;

const OrdersList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const OrderCard = styled.div`
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
  }
`;

const OrderTitle = styled.h3`
  font-size: 1.6rem;
  margin-bottom: 10px;
`;

const OrderDetails = styled.p`
  font-size: 1.2rem;
  color: #555;
`;

const Loader = styled.div`
  text-align: center;
  font-size: 1.5rem;
  color: #333;
`;

const Error = styled.div`
  text-align: center;
  font-size: 1.5rem;
  color: red;
`;

// Modal Styling
const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5); // Background overlay
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContainer = styled.div`
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  width: 400px;
  max-width: 100%;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
`;

const ModalTitle = styled.h3`
  margin-bottom: 20px;
  font-size: 1.5rem;
  text-align: center;
`;

const ModalButton = styled.button`
  padding: 10px 20px;
  font-size: 1rem;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const ModalActions = styled.div`
  display: flex;
  justify-content: space-between;
`;

// Orders Component
const OrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null); // State to store selected order
  const [selectedUserId, setSelectedUserId] = useState(null); // Track user ID for selected order
  const [showModal, setShowModal] = useState(false); // State for modal visibility

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const ordersCollection = collection(db, 'orders'); // Top-level 'orders' collection
        const ordersSnapshot = await getDocs(ordersCollection);
        const allOrders = [];

        ordersSnapshot.forEach(doc => {
          const userOrders = doc.data().orders; // Access the array of orders
          if (Array.isArray(userOrders)) {
            userOrders.forEach(order => {
              allOrders.push({
                userId: doc.id, // Document ID represents the user
                ...order, // Spread the order details
              });
            });
          }
        });

        setOrders(allOrders);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError('Failed to load orders. Please try again later.');
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  const handleAcceptOrder = async () => {
    if (selectedOrder && selectedUserId) {
      const orderRef = doc(db, 'orders', selectedUserId); // Use user ID for the document reference
  
      try {
        // Fetch the current orders array from Firestore
        const orderDoc = await getDoc(orderRef);
        const ordersArray = orderDoc.data().orders;
  
        // Update the status of the selected product/order
        const updatedOrders = ordersArray.map(order =>
          order.id === selectedOrder.id ? { ...order, status: 'Accepted' } : order
        );
  
        // Update the orders array in Firestore
        await updateDoc(orderRef, {
          orders: updatedOrders
        });
  
        // Update the specific order in the state to reflect the changes
        setOrders(prevOrders =>
          prevOrders.map(order =>
            order.id === selectedOrder.id ? { ...order, status: 'Accepted' } : order
          )
        );
  
        setShowModal(false); // Close the modal
      } catch (err) {
        console.error("Error updating order:", err);
        setError('Failed to update the order status. Please try again.');
      }
    }
  };
  
  const handleDeny = async () => {
    if (selectedOrder && selectedUserId) {
      const orderRef = doc(db, 'orders', selectedUserId); // Use user ID for the document reference
  
      try {
        // Fetch the current orders array from Firestore
        const orderDoc = await getDoc(orderRef);
        const ordersArray = orderDoc.data().orders;
  
        // Update the status of the selected product/order
        const updatedOrders = ordersArray.map(order =>
          order.id === selectedOrder.id ? { ...order, status: 'Denied' } : order
        );
  
        // Update the orders array in Firestore
        await updateDoc(orderRef, {
          orders: updatedOrders
        });
  
        // Update the specific order in the state to reflect the changes
        setOrders(prevOrders =>
          prevOrders.map(order =>
            order.id === selectedOrder.id ? { ...order, status: 'Denied' } : order
          )
        );
  
        setShowModal(false); // Close the modal
      } catch (err) {
        console.error("Error updating order:", err);
        setError('Failed to update the order status. Please try again.');
      }
    }
  };
  

  const handleCloseModal = () => {
    setShowModal(false); // Close the modal when clicking outside or on cancel
  };

  if (loading) return <Loader>Loading orders...</Loader>;
  if (error) return <Error>{error}</Error>;

  return (
    <OrdersContainer>
      <Header>Your Orders</Header>
      {orders.length > 0 ? (
        <OrdersList>
          {orders.map((order, index) => (
            <OrderCard key={index} onClick={() => { 
              setSelectedOrder(order); 
              setSelectedUserId(order.userId); // Track the user ID for the selected order
              setShowModal(true); 
            }}>
              <OrderTitle>Order for User: {order.userId}</OrderTitle>
              <OrderDetails>Product Name: {order.cropName}</OrderDetails>
              <OrderDetails>Quantity: {order.quantity}</OrderDetails>
              <OrderDetails>Price: ₹{order.totalPrice}</OrderDetails>
              <OrderDetails>Status: {order.status}</OrderDetails>
            </OrderCard>
          ))}
        </OrdersList>
      ) : (
        <Error>No orders found.</Error>
      )}

      {showModal && (
        <ModalOverlay onClick={handleCloseModal}>
          <ModalContainer onClick={(e) => e.stopPropagation()}> {/* Prevent closing on clicking inside */}
            <ModalTitle>Do you want to accept this order?</ModalTitle>
            <ModalActions>
              <ModalButton onClick={handleAcceptOrder}>Accept</ModalButton>
              <ModalButton onClick={handleCloseModal}>Cancel</ModalButton>
              <ModalButton onClick={handleDeny}>Deny</ModalButton>
            </ModalActions>
          </ModalContainer>
        </ModalOverlay>
      )}
    </OrdersContainer>
  );
};

export default OrdersPage;
