import { useEffect, useState } from 'react';
import { getDoc, doc } from 'firebase/firestore';
import { db } from './firebase2'; // Import Firebase config
import { useUser } from './UserContext'; // Assuming this is where you're managing user context

const useAadhar = () => {
  const { user } = useUser();
  const [aadhar, setAadhar] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      const fetchAadhar = async () => {
        try {
          const docRef = doc(db, 'farmer_data', user.uid); // Get the document by UID
          const docSnap = await getDoc(docRef);

          if (docSnap.exists()) {
            setAadhar(docSnap.data().aadhar); // Set the fetched Aadhar
          } else {
            console.log('No such document!');
          }
        } catch (error) {
          console.error('Error fetching Aadhar:', error);
        } finally {
          setLoading(false);
        }
      };

      fetchAadhar();
    }
  }, [user]);

  return { aadhar, loading };
};

export default useAadhar;
