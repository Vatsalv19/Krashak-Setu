import React from 'react';
import ContactForm from '../components/ContactForm';
import styled from 'styled-components';

const Container = styled.div`
  padding: 20px;
  max-width: 600px;
  margin: 0 auto;
`;

const ContactPage = () => {
  return (
    <Container>
      <h2>Contact Us</h2>
      <p>If you have any questions, feel free to reach out to us using the form below.</p>
      <ContactForm />
    </Container>
  );
};

export default ContactPage;
