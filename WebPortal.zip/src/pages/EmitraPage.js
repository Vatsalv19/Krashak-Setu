import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { FiMenu, FiX } from 'react-icons/fi';
import FaQ from '../components/FaQ';



// Styled Components for Home Page
const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  color: #fff;
  font-family: 'Arial', sans-serif;
`;

const NavBar = styled.nav`
  width: 100%;
  background-color: ${({ scrolled }) => (scrolled ? 'rgba(0, 0, 0, 0.9)' : 'rgba(0, 0, 0, 0.7)')};
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  transition: background-color 0.3s ease;
`;

const Logo = styled.div`
  font-size: 1.8rem;
  font-weight: bold;
  color: #228B22;
`;

const NavMenu = styled.ul`
  list-style: none;
  display: flex;
  gap: 20px;
  margin: 0;
  padding: 0;
  @media (max-width: 768px) {
    flex-direction: column;
    background-color: rgba(0, 0, 0, 0.9);
    position: absolute;
    top: 60px;
    right: 0;
    width: 200px;
    padding: 20px;
    border-radius: 0 0 10px 10px;
    display: ${({ isOpen }) => (isOpen ? 'flex' : 'none')};
  }
`;

const NavItem = styled.li`
  margin: 10px 0;
  @media (min-width: 769px) {
    margin: 0;
  }
`;

const StyledLink = styled(Link)`
  color: white;
  text-decoration: none;
  font-size: 1.1rem;
  font-weight: bold;
  transition: all 0.3s ease;
  &:hover {
    color: #feb47b;
  }
`;

const MenuIcon = styled.div`
  display: none;
  font-size: 2rem;
  cursor: pointer;
  @media (max-width: 768px) {
    display: block;
  }
`;

const SliderContainer = styled.div`
  position: relative;
  width: 100%;
  height: 90vh;
  overflow: hidden;
  margin-top: 60px;
  @media (max-width: 768px) {
    height: 50vh;
  }
`;

const Slider = styled.div`
  display: flex;
  transition: transform 0.5s ease-in-out;
`;

const Slide = styled.div`
  min-width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const Overlay = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: white;
  font-size: 2rem;
  font-weight: bold;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  z-index: 10;
`;

const ScrollButton = styled.button`
  position: absolute;
  bottom: 200px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #feb47b;
  color: white;
  font-size: 1.1rem;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  z-index: 10;
  &:hover {
    background-color: #ff7e5f;
  }
`;
// Add these styled components above your Home component
const DropdownContainer = styled.div`
  position: relative;
  display: inline-block;
`;

const DropdownButton = styled.button`
  background-color: #228B22;
  color: white;
  padding: 10px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1rem;
  &:hover {
    background-color: #196f14;
  }
`;

const DropdownMenu = styled.div`
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
  position: absolute;
  background-color: #fff;
  color: black;
  box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
  border-radius: 5px;
  margin-top: 10px;
  z-index: 1000;
`;

const DropdownMenuItem = styled.div`
  padding: 10px;
  cursor: pointer;
  &:hover {
    background-color: #f1f1f1;
  }
`;
const Footer = styled.footer`
  width: 100%;
  padding: 40px 20px;
  background-color: #333;
  color: white;
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Three columns */
  gap: 40px;
  text-align: left;
  @media (max-width: 768px) {
    grid-template-columns: 1fr; /* Single column on smaller screens */
    text-align: center;
  }
`;

const FooterSection = styled.div`
  h3 {
    font-size: 1.5rem;
    color: #fff;
    margin-bottom: 10px;
  }
`;

const FooterLink = styled(Link)`
  color: #bbb;
  text-decoration: none;
  font-size: 1rem;
  display: block;
  margin: 5px 0;
  transition: color 0.3s ease;
  &:hover {
    color: #feb47b;
  }
`;

const FooterCopy = styled.div`
  grid-column: span 3;
  text-align: center;
  font-size: 0.9rem;
  color: #bbb;
  margin-top: 20px;
  @media (max-width: 768px) {
    grid-column: span 1;
  }
`;

const FooterSocial = styled.div`
  display: flex;
  gap: 15px;
  justify-content: center;
  margin-top: 20px;
  font-size: 1.5rem;
  a {
    color: #bbb;
    transition: color 0.3s ease;
    &:hover {
      color: #feb47b;
    }
  }
`;
// const Footer = styled.footer`
//   width: 100%;
//   padding: 20px;
//   background-color: #333;
//   color: white;
//   text-align: center;
//   position: relative;
//   bottom: 0;
// `;

const CardContainer = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: flex-start;
  margin: 40px auto;
  padding: 20px;
  width: 100%;
  margin-top:320px;
  max-width: 1200px;
  gap: 20px;
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
  }
`;

const Card = styled.div`
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 300px;
  width: 100%;
  padding: 20px;
  text-align: center;
  transition: transform 0.3s ease;
  &:hover {
    transform: translateY(-0px);
     box-shadow: 0 4px 8px rgba(20, 30, 10, 0.1);
  }
`;

const CardImage = styled.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  object-fit: cover;
  margin: 0 auto 15px;
  display: block;
`;

const CardTitle = styled.h3`
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 10px;
`;

const CardDescription = styled.p`
  color: #555;
  font-size: 1rem;
`;



// New Styled Components for Main Content
const MainContent = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 40px;
  padding: 20px;
  width: 100%;
  max-width: 1200px;
  margin: 40px auto;
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
  
  }
`;

const CircularImage = styled.img`
  border-radius: 50%;
  width: 300px;
  height: 300px;
  object-fit: cover;
  @media (max-width: 768px) {
    width: 200px;
    height: 200px;
  }
`;

const TextContent = styled.div`
  max-width: 600px;
  margin-left: 20px;
  text-align: left;
  color: #333; /* Change this to any color you prefer */
  
  @media (max-width: 768px) {
    margin-left: 0;
    margin-top: 20px;
    text-align: center;
  }
`;
const SummarySection = styled.div`
  width: 100%;
  max-width: 1200px;
  margin: 40px auto;
  padding: 20px;
  text-align: center;
  border-radius: 8px;
`;

const SummaryTitle = styled.h2`
  font-size: 2rem;
  color: #333;
  margin-bottom: 15px;
`;

const SummaryText = styled.p`
  font-size: 1.1rem;
  color: #555;
  line-height: 1.6;
  max-width: 900px;
  margin: 0 auto;
`;

// Main Home Component
const EmitraPage = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const handleScroll = () => {
    setScrolled(window.scrollY > 50);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Container>
      <NavBar scrolled={scrolled}>
        <Logo>Farmers Portal</Logo>
        <MenuIcon onClick={toggleMenu}>
          {menuOpen ? <FiX /> : <FiMenu />}
        </MenuIcon>
        <NavMenu isOpen={menuOpen}>
          <NavItem><StyledLink to="/">Home</StyledLink></NavItem>
          <NavItem><StyledLink to="/">About</StyledLink></NavItem>
          <NavItem><StyledLink to="/">Contact</StyledLink></NavItem>
          <DropdownContainer>
            <DropdownButton onClick={toggleDropdown}>More</DropdownButton>
            <DropdownMenu isOpen={dropdownOpen}>
              <DropdownMenuItem><StyledLink to="/services">Services</StyledLink></DropdownMenuItem>
              <DropdownMenuItem><StyledLink to="/resources">Resources</StyledLink></DropdownMenuItem>
              <DropdownMenuItem><StyledLink to="/community">Community</StyledLink></DropdownMenuItem>
            </DropdownMenu>
          </DropdownContainer>
        </NavMenu>
      </NavBar>

      <CardContainer>
  <Link to="/FarmerLogin" style={{ textDecoration: 'none' }}>
    <Card>
      <CardImage src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9hrRPb33NRB_rudIvr7wHZBiOgx4EXOSIgA&s" alt="E-Mitra Login" />
      <CardTitle>Login as Farmer</CardTitle>
      <CardDescription>This is a brief description of the E-Mitra login card.</CardDescription>
    </Card>
  </Link>
  <Link to="/FarmerRegistrationForm" style={{ textDecoration: 'none' }}>
    <Card>
      <CardImage src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9hrRPb33NRB_rudIvr7wHZBiOgx4EXOSIgA&s" alt="Government Services Login" />
      <CardTitle>Create Account</CardTitle>
      <CardDescription>This is a brief description of the Government Services login card.</CardDescription>
    </Card>
  </Link>
  
</CardContainer>



  {/* Summary Section About Agriculture and Development */}
  <SummarySection>
        <SummaryTitle>Summery</SummaryTitle>
        <SummaryText>
          Agriculture plays a central role in the economy of many countries, providing not only food but also employment and economic opportunities for millions of people. As the global population grows, the need for sustainable farming practices and innovative solutions becomes more critical. Our platform aims to bridge the gap between farmers, resources, and knowledge, ensuring that agricultural development continues to thrive and evolve in a sustainable manner.
        </SummaryText>
      </SummarySection>
      <FaQ/>
       
      <Footer>
        
        <FooterSection>
          <h3>About Us</h3>
          <FooterLink to="/about">About the Farmers Portal</FooterLink>
          <FooterLink to="/services">Our Services</FooterLink>
          <FooterLink to="/community">Join our Community</FooterLink>
        </FooterSection>
        
        <FooterSection>
          <h3>Useful Links</h3>
          <FooterLink to="/contact">Contact Us</FooterLink>
          <FooterLink to="/privacy-policy">Privacy Policy</FooterLink>
          <FooterLink to="/terms">Terms and Conditions</FooterLink>
        </FooterSection>

        <FooterSection>
          <h3>Government Resources</h3>
          <FooterLink to="https://www.india.gov.in" target="_blank" rel="noopener noreferrer">India Government</FooterLink>
          <FooterLink to="https://www.mygov.in" target="_blank" rel="noopener noreferrer">MyGov India</FooterLink>
          <FooterLink to="https://pmksy.gov.in" target="_blank" rel="noopener noreferrer">PM Kisan Scheme</FooterLink>
        </FooterSection>
        
        <FooterCopy>
          <p>&copy; 2024 Farmers Portal. All rights reserved.</p>
        
        </FooterCopy>
      </Footer>
    </Container>
   
  );
};


export default EmitraPage;
