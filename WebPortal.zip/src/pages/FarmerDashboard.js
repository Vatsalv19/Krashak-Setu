import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { FiHome, FiUser, FiShoppingCart, FiBook, FiLogOut, FiPlus } from 'react-icons/fi';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useUser } from './UserContext'; // Import the useUser hook
import Cookies from 'js-cookie';
import Sliderbar from '../components/Sliderbar';

// Styled Components
const Container = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  font-family: Arial, sans-serif;
background-color:#FFF8DC;

`;

const DashboardContent = styled.div`
  margin-left: 250px;
  padding: 40px;
  width: 90%;
  flex-grow: 1;
  text-align: center;
  @media (max-width: 768px) {
    margin-left: 0;
    padding: 20px;
  }
`;
const Header = styled.h1`
  font-size: 3rem;
  color:black;
  margin-bottom: 20px;
  text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
  font-family: 'Poppins', sans-serif;

  @media (max-width: 768px) {
    font-size: 2.5rem;
  }

  span {
    color: #3498db;
    animation: pulse 1.5s infinite;
  }

  @keyframes pulse {
    0%, 100% {
      text-shadow: 0 0 5px #3498db, 0 0 10px #3498db, 0 0 20px #3498db;
    }
    50% {
      text-shadow: 0 0 10px #2980b9, 0 0 15px #2980b9, 0 0 30px #2980b9;
    }
  }
`;
const DashboardCards = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 25px;
  margin-top: 40px;
  padding: 10px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 20px;
  }
`;


const Card = styled.div`
  background-color: #FDF5E6;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
  width: 640px; /* Set the width */
  height: 200px; /* Set the height */
  
  &:hover {
    transform: translateX(-3px);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
  }

  @media (max-width: 768px) {
    padding: 15px;
    width: 100%; /* Adjust width for smaller screens */
    height: auto; /* Let height adjust automatically on smaller screens */
  }
`;


const CardTitle = styled.h3`
  font-size: 1.6rem;
  margin-bottom: 10px;
  
  @media (max-width: 768px) {
    font-size: 1.4rem;
  }
`;

const CardContent = styled.p`
  font-size: 1.2rem;
  color: #555;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
`;

const CardFooter = styled.div`
  margin-top: 20px;
  text-align: right;
  font-weight: bold;
  color: #228B22;
`;

const AddProductButton = styled.button`
  background-color: #228B22;
  color: white;
  font-size: 1.2rem;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #1c6d1c;
  }

  &:focus {
    outline: none;
  }
`;


const FarmerDashboard = () => {
  const navigate = useNavigate();
  const { user } = useUser();  // Get user data from the context
  const [aadhar, setAadhar] = useState(null);

  // Fetching Aadhar from the cookie (use only if user data is not available in context)
  useEffect(() => {
    if (!user) {
      const storedAadhar = Cookies.get('aadhar');
      console.log('Fetched Aadhar from cookie:', storedAadhar);  // Debugging
      if (storedAadhar) {
        setAadhar(storedAadhar);  // Store aadhar in state if found
      }
    } else {
      setAadhar(user.aadhar);  // If user is available, use aadhar from context
    }
  }, [user]);

  const handleAddProduct = () => {
    if (aadhar) {
      console.log('Navigating to AddProductPage with Aadhar:', aadhar); // Debugging
      navigate(`/addproduct?aadhar=${aadhar}`);
    } else {
      alert('No Aadhar number found!');
    }
  };

  return (
    <Container>
  <Sliderbar/>


      <DashboardContent>
        <Header>Welcome to Your Dashboard</Header>
       {user && (
          <p>Your Aadhar Number: {user.aadhar}</p> // Displaying the Aadhar
        )}
         
        <DashboardCards>
       
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
         <Card>
        <CardTitle>Orders</CardTitle>
        <CardContent>You have 5 new orders awaiting confirmation.</CardContent>
        <Link to="/OrdersPage" style={{ textDecoration: 'none', color: '#228B22', fontWeight: 'bold' }}>
          View Orders
        </Link>
      </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <CardTitle>Resources</CardTitle>
              <CardContent>Check which crop will have the highest quantity sold in the next month.</CardContent>
              <Link to="/PridictiveProduct" style={{ textDecoration: 'none', color: '#228B22', fontWeight: 'bold' }}>
        View Prediction
        </Link>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <Card>
              <CardTitle>Messages</CardTitle>
              <CardContent>You have 3 unread messages from your community.</CardContent>
              <CardFooter>View Messages</CardFooter>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <AddProductButton onClick={handleAddProduct}>
              <FiPlus /> Add Product
            </AddProductButton>
          </motion.div>
        </DashboardCards>
      </DashboardContent>
    </Container>
  );
};

export default FarmerDashboard;
