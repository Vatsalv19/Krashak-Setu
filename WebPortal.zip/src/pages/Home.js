import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import './Home.css';
import Carousel from '../components/Carousel';
import Navbar from '../components/Navbar';
// import PartnersImage from '../../assets/Partners.jpg'; // Import the image
import WhySection from '../components/Whysection';
import PartnerCarousel from '../components/PartnerCarousel';
import WhatIsKrashakSetu from '../components/WhatIsKrashakSetu';
import DesignThinking from '../components/DesignThinking';
import Testimonials from '../components/Testimonials';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Footer.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter, faInstagram, faYoutube } from '@fortawesome/free-brands-svg-icons';
const Home = () => {
  return (
    <div>
      {/* Background Image and Content */}
      <div
  className="bg-image-container"
  style={{
    backgroundImage: `url('https://c4.wallpaperflare.com/wallpaper/60/76/964/agriculture-farmer-field-hut-wallpaper-preview.jpg')`, // Directly use the URL as a string
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
    minHeight: '50vh', // Full viewport height
  }}
  
      >
        {/* Navbar Component */}
        <Navbar />

        {/* Hero Section */}
        <div className="hero-content text-center text-white py-5">
  <h1 className="display-4 font-weight-bold mb-4">
    Welcome to the Government Portal for Rural Development
  </h1>
  <p className="lead mb-4">
    Empowering farmers, facilitating government schemes, and improving rural life.
  </p>
  <button className="btn btn-light btn-lg">Explore Government Schemes</button>
</div>

      </div>


      {/* Carousel Section */}
      <div>
        <Carousel />
      </div>

      <div>
      <Testimonials />
    </div>
    
        <div>
          <WhySection />
        </div>
        
    
      <div>
     < WhatIsKrashakSetu />
      </div>
      <div>
      <PartnerCarousel />
      </div>

      {/* Footer Section */}
      <div>
      {/* <Footer /> */}
      </div>
      <footer className="footer bg-dark text-white pt-4 pb-2">
      <div className="container">
        <div className="row">
          {/* About Us Section */}
          <div className="col-md-4">
            <h5>About Us</h5>
            <p>
              We are dedicated to improving the lives of farmers by providing them with resources,
              tools, and access to various government schemes. Our aim is to support the rural community.
            </p>
          </div>

          {/* Quick Links Section */}
          <div className="col-md-4">
            <h5>Quick Links</h5>
            <ul className="list-unstyled">
              <li>
                <Link to="https://www.india.gov.in/my-government/schemes-0" className="text-white">Government Schemes</Link>
              </li>
              <li>
                <Link to="/resources" className="text-white">Resources</Link>
              </li>
              <li>
                <Link to="/contact" className="text-white">Contact Us</Link>
              </li>
              <li>
                <Link to="/faq" className="text-white">FAQs</Link>
              </li>
            </ul>
          </div>

          {/* Social Media Links Section */}
          <div className="col-md-4">
            <h5>Connect with Us</h5>
            <div className="social-links">
              <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
                <FontAwesomeIcon icon={faFacebook} size="2x" />
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
                <FontAwesomeIcon icon={faTwitter} size="2x" />
              </a>
              <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
                <FontAwesomeIcon icon={faInstagram} size="2x" />
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
                <FontAwesomeIcon icon={faYoutube} size="2x" />
              </a>
            </div>
          </div>
        </div>
        <hr className="bg-light" />
        {/* Copyright Section */}
        <div className="text-center">
          <p className="mb-0">&copy; {new Date().getFullYear()} Farmer Portal. All rights reserved.</p>
        </div>
      </div>
    </footer>
    </div>
  );
};

export default Home;
