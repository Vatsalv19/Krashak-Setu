import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import { getDocs, doc, query, collection, updateDoc, deleteDoc, where } from 'firebase/firestore';
import { getDownloadURL, ref } from 'firebase/storage';
import { db, storage } from './firebase';
import { useUser } from './UserContext';
import Sliderbar from '../components/Sliderbar';

// Theme for styling
const theme = {
  primary: '#4C9AFF',
  secondary: '#28C76F',
  accent: '#FBB13C',
  danger: '#FF4C4C',
  lightBackground: '#F5F7FA',
  darkBackground: '#2E3A59',
  textPrimary: '#2E3A59',
  textSecondary: '#6B778C',
};

// Card fade-in animation
const cardFadeIn = keyframes`
  0% { opacity: 0; transform: translateY(10px); }
  100% { opacity: 1; transform: translateY(0); }
`;

// Modal scale-in animation
const modalFadeIn = keyframes`
  0% { opacity: 0; transform: scale(0.95); }
  100% { opacity: 1; transform: scale(1); }
`;

const Container = styled.div`
  margin-left: 280px;
  padding: 40px;
  background-color: ${theme.lightBackground};
  min-height: 100vh;
  animation: ${cardFadeIn} 1s ease-in-out;

  @media (max-width: 768px) {
    margin-left: 0;
    padding: 20px;
  }

  h1 {
    color: ${theme.textPrimary};
    font-size: 2.8rem;
    margin-bottom: 30px;
    text-align: center;
  }
`;

const CardList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 25px;
  max-width: 1200px;
  margin: 0 auto;
`;

const Card = styled.div`
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  padding: 20px;
  display: flex;
  flex-direction: column;
  height: 100%;
  opacity: 0;
  transform: translateY(10px);
  animation: ${cardFadeIn} 1s ease-in-out forwards;

  &:nth-child(1) {
    animation-delay: 0.2s;
  }

  &:nth-child(2) {
    animation-delay: 0.4s;
  }

  &:nth-child(3) {
    animation-delay: 0.6s;
  }

  &:nth-child(4) {
    animation-delay: 0.8s;
  }
`;

const Image = styled.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 12px;
  margin-bottom: 20px;
  transition: transform 0.3s ease;

  &:hover {
    transform: scale(1.05);
  }
`;

const Title = styled.h3`
  color: ${theme.textPrimary};
  font-size: 1.8rem;
  font-weight: bold;
  margin-bottom: 10px;
`;

const Category = styled.p`
  color: ${theme.textSecondary};
  font-size: 1rem;
  margin-bottom: 10px;
`;

const Price = styled.p`
  color: ${theme.secondary};
  font-size: 1.4rem;
  font-weight: bold;
  margin-bottom: 10px;
`;

const Quantity = styled.p`
  color: ${theme.textPrimary};
  font-size: 1rem;
`;

const ButtonWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-top: auto;
`;

const Button = styled.button`
  background-color: ${(props) => (props.danger ? theme.danger : theme.secondary)};
  color: white;
  border: none;
  padding: 12px 16px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 1rem;
  font-weight: 600;
  flex: 1;
  transition: background 0.4s ease, transform 0.3s ease;

  &:hover {
    background-color: ${(props) => (props.danger ? '#D64545' : '#219150')};
    transform: translateY(-3px);
  }

  &:active {
    transform: translateY(0);
  }
`;

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background-color: white;
  padding: 30px;
  border-radius: 12px;
  width: 500px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  animation: ${modalFadeIn} 0.5s ease-in-out;

  h3 {
    color: ${theme.textPrimary};
    font-size: 2rem;
    margin-bottom: 20px;
  }
`;

const Input = styled.input`
  width: 100%;
  padding: 14px;
  margin: 12px 0;
  border: 1px solid ${theme.textSecondary};
  border-radius: 10px;
  font-size: 1rem;
`;

const ProductListPage = () => {
  const { user } = useUser();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState(null);
  const [editedProduct, setEditedProduct] = useState({
    name: '',
    category: '',
    price: '',
    quantity: '',
  });

  // Fetch crops based on Aadhar
  useEffect(() => {
    const fetchCrops = async () => {
      if (user?.aadhar) {
        const cropsCollectionRef = collection(db, 'crops'); // Reference to the crops collection
        const cropsQuery = query(cropsCollectionRef, where('aadhar', '==', user.aadhar)); // Query for crops with matching Aadhar

        try {
          const querySnapshot = await getDocs(cropsQuery);
          const cropsList = querySnapshot.docs.map(async (doc) => {
            const productData = { id: doc.id, ...doc.data() };
            if (productData.imageurl) {
              try {
                const url = await getDownloadURL(ref(storage, productData.imageurl));
                productData.imageurl = url;
              } catch {
                productData.imageurl = ''; // If no image available, set default
              }
            }
            return productData;
          });
          const cropsWithImages = await Promise.all(cropsList);
          setProducts(cropsWithImages);
        } catch (error) {
          console.error('Error fetching crops:', error);
        } finally {
          setLoading(false);
        }
      } else {
        setLoading(false);
      }
    };

    fetchCrops();
  }, [user]);

  if (loading) {
    return <Container>Loading...</Container>;
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedProduct((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSaveChanges = async () => {
    if (currentProduct) {
      const productDocRef = doc(db, 'crops', currentProduct.id);

      try {
        await updateDoc(productDocRef, editedProduct);
        setProducts((prev) =>
          prev.map((product) =>
            product.id === currentProduct.id ? { ...product, ...editedProduct } : product
          )
        );
        setIsModalOpen(false);
      } catch (error) {
        console.error('Error updating product:', error);
      }
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (window.confirm('Are you sure you want to delete this crop?')) {
      try {
        const productDocRef = doc(db, 'crops', productId);
        await deleteDoc(productDocRef);
        setProducts(products.filter((product) => product.id !== productId));
      } catch (error) {
        console.error('Error deleting crop:', error);
        alert('Failed to delete the crop.');
      }
    }
  };

  return (
    <Container>
      <Sliderbar />
      <h1>Your Crops</h1>
      <CardList>
        {products.map((product) => (
          <Card key={product.id}>
            <Image src={product.imageurl || 'https://via.placeholder.com/180'} alt={product.name} />
            <Title>{product.name}</Title>
            <Category>{product.category}</Category>
            <Price>Rs.{product.price}</Price>
            <Quantity>Quantity: {product.quantity}</Quantity>
            <Button onClick={() => setIsModalOpen(true)}>Edit</Button>
            <Button danger onClick={() => handleDeleteProduct(product.id)}>
              Delete
            </Button>
          </Card>
        ))}
      </CardList>

      {isModalOpen && (
        <ModalOverlay>
          <ModalContent>
            <h3>Edit Crop</h3>
            <Input
              name="name"
              value={editedProduct.name}
              onChange={handleInputChange}
              placeholder="Crop Name"
            />
            <Input
              name="category"
              value={editedProduct.category}
              onChange={handleInputChange}
              placeholder="Category"
            />
            <Input
              name="price"
              value={editedProduct.price}
              onChange={handleInputChange}
              placeholder="Price"
            />
            <Input
              name="quantity"
              value={editedProduct.quantity}
              onChange={handleInputChange}
              placeholder="Quantity"
            />
            <Button onClick={handleSaveChanges}>Save</Button>
            <Button danger onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
          </ModalContent>
        </ModalOverlay>
      )}
    </Container>
  );
};

export default ProductListPage;
