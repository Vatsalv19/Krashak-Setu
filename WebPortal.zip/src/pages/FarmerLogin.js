import React, { useState } from 'react';
import { db } from './firebase2'; // Firestore instance
import { doc, getDoc } from 'firebase/firestore'; // Firestore methods
import { useNavigate } from 'react-router-dom'; // For navigation
import Cookies from 'js-cookie'; // Import js-cookie

const FarmerLogin = () => {
  const [aadhar, setAadhar] = useState(''); // Aadhar input
  const [password, setPassword] = useState(''); // Password input
  const navigate = useNavigate();

  // Function to handle login
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate Aadhar number format
    if (aadhar.length !== 12 || isNaN(aadhar)) {
      alert('Please enter a valid 12-digit Aadhar number.');
      return;
    }

    try {
      // Fetch farmer data by Aadhar number
      const farmerDoc = await getDoc(doc(db, 'farmer_data', aadhar));
      if (farmerDoc.exists()) {
        const farmerData = farmerDoc.data();
        
        // Check if the entered password matches the stored password
        if (farmerData.password === password) {
          // Save Aadhar number in cookies
          Cookies.set('aadhar', aadhar, { expires: 7 }); // Expires in 7 days

          // Redirect to FarmerDashboard
          navigate('/FarmerDashboard', { state: { farmerData } });
        } else {
          alert('Incorrect password. Please try again.');
        }
      } else {
        alert('Invalid Aadhar number or user does not exist.');
      }
    } catch (error) {
      console.error('Error during login:', error.message);
      alert('An error occurred while logging in. Please try again.');
    }
  };

  return (
    <div className="container">
      <div className="form-container">
        <div className="header">
          <img
            src="mylogo.jpeg"
            alt="logo"
            className="logo"
          />
          <h4 className="form-title">Farmer Login</h4>
        </div>

        <p className="form-description">Please login using your Aadhar number and password</p>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            className="input-field"
            value={aadhar}
            onChange={(e) => setAadhar(e.target.value)}
            placeholder="Enter Aadhar Number"
            required
          />

          <input
            type="password"
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter Password"
            required
          />

          <button type="submit" className="submit-btn">Login</button>
        </form>

        <div className="footer">
  
        </div>
      </div>

      <style>
        {`
          /* Overall container for centering the login form */
          .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
            font-family: Arial, sans-serif;
          
          }

          /* Main form container styling */
          .form-container {
          width:100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: white;
            padding: 30px;
            border-radius: 20px;
            width: 100%;
            box-shadow: 0 4px 8px rgba(0.1, 0, 0, 0.1);
            text-align: center;
          }

          /* Header section */
          .header {
            margin-bottom: 20px;
          }

          .logo {
            width: 150px;
            margin-bottom: 20px;
            border-radius:113px;
          }

          .form-title {
            font-size: 32px;
            color: royalblue;
            font-weight: 600;
            margin-bottom: 20px;
          }

          /* Description text */
          .form-description {
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
          }

          /* Input field styling */
          .input-field {
            width: 100%;
            padding: 12px;
            outline: none;
            border: 1px solid rgba(105, 105, 105, 0.397);
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 16px;
            box-sizing: border-box;
          }

          /* Submit button */
          .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #ee7724;
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            cursor: pointer;
          }

          .submit-btn:hover {
            background-color: #d8363a;
          }

          /* Footer section */
          .footer {
            margin-top: 20px;
          }

          .footer-text {
            font-size: 14px;
            color: #555;
          }

          .sign-up-btn {
            background: none;
            border: 1px solid #d8363a;
            color: #d8363a;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 5px;
          }

          .sign-up-btn:hover {
            background-color: #d8363a;
            color: white;
          }

          /* Info section styling */
          .info-section {
            margin-top: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #fccb90;
            border-radius: 15px;
            padding: 30px;
          }

          .info-text {
            text-align: center;
            color: white;
          }

          .info-text h4 {
            font-size: 26px;
            margin-bottom: 15px;
          }

          .info-text p {
            font-size: 16px;
          }

          /* Responsive Design: Adjustments for small screens */
          @media (max-width: 600px) {
            .form-container {
              padding: 20px;
              max-width: 100%;
            }

            .logo {
              width: 120px;
            }

            .form-title {
              font-size: 28px;
            }

            .input-field, .submit-btn, .sign-up-btn {
              font-size: 14px;
            }
          }
        `}
      </style>
    </div>
  );
};

export default FarmerLogin;
