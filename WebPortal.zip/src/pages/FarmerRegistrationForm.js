import React, { useState } from 'react';
import styled from 'styled-components';
import { db } from './firebase2';
import { collection, setDoc, doc } from 'firebase/firestore';

const Container = styled.div`
  padding: 20px;
  max-width: 1200px;
  margin: 50px auto;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

const FormTitle = styled.h2`
  margin-bottom: 20px;
  text-align: center;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border-radius: 4px;
  border: 1px solid ${(props) => (props.verified ? 'green' : '#ccc')};
  background-color: ${(props) => (props.verified ? '#e7fbe7' : 'white')};
`;

const Button = styled.button`
  padding: 10px 20px;
  background-color: ${(props) => (props.secondary ? '#4caf50' : '#228B22')};
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-right: ${(props) => (props.secondary ? '10px' : '0')};

  &:hover {
    background-color: ${(props) => (props.secondary ? '#45a049' : '#1c6d1c')};
  }
`;

const Popup = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 20px;
  z-index: 1000;
  max-width: 400px;
  text-align: center;
`;

const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
`;

const FarmerRegistrationForm = () => {
  const [formData, setFormData] = useState({
    aadhar: '',
    accountNumber: '',
    address: '',
    bankBranch: '',
    district: '',
    ifscCode: '',
    landArea: '',
    landmark: '',
    mainCrops: '',
    name: '',
    phone: '',
    pincode: '',
    state: '',
    tehsil: '',
    village: '',
    password: '', // New password field
    emitraGmailId: '', // New EMitra Gmail ID field
  });
  const [isAadharVerified, setIsAadharVerified] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupMessage, setPopupMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleVerify = () => {
    if (formData.aadhar.length === 12 && /^\d+$/.test(formData.aadhar)) {
      setIsAadharVerified(true);
      setPopupMessage('Aadhar Verified Successfully!');
    } else {
      setPopupMessage('Invalid Aadhar Number. Please enter a valid 12-digit number.');
    }
    setPopupVisible(true);
  };

  const closePopup = () => {
    setPopupVisible(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await registerFarmer(formData);
      alert('Farmer registered successfully!');
      setFormData({
        aadhar: '',
        accountNumber: '',
        address: '',
        bankBranch: '',
        district: '',
        ifscCode: '',
        landArea: '',
        landmark: '',
        mainCrops: '',
        name: '',
        phone: '',
        pincode: '',
        state: '',
        tehsil: '',
        village: '',
        password: '', // Reset password
        emitraGmailId: '', // Reset EMitra Gmail ID
      });
      setIsAadharVerified(false);
    } catch (error) {
      console.error('Error registering farmer:', error);
      alert('Failed to register farmer.');
    }
  };

  const registerFarmer = async (farmerData) => {
    try {
      const farmerDocRef = doc(collection(db, 'farmer_data'), farmerData.aadhar);
      await setDoc(farmerDocRef, farmerData);
      const cropsCollectionName = `crops_${farmerData.aadhar}`;
      const cropsCollectionRef = collection(db, cropsCollectionName);
      console.log(`Collection ${cropsCollectionName} is now ready for storing crops.`);
    } catch (error) {
      console.error('Error registering farmer:', error);
    }
  };

  return (
    <Container>
      <FormTitle>Farmer Registration</FormTitle>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <Label htmlFor="aadhar">Aadhar Number</Label>
          <Input
            type="text"
            id="aadhar"
            name="aadhar"
            value={formData.aadhar}
            onChange={handleChange}
            verified={isAadharVerified}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="accountNumber">Account Number</Label>
          <Input
            type="text"
            id="accountNumber"
            name="accountNumber"
            value={formData.accountNumber}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="address">Address</Label>
          <Input
            type="text"
            id="address"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="bankBranch">Bank Branch</Label>
          <Input
            type="text"
            id="bankBranch"
            name="bankBranch"
            value={formData.bankBranch}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="district">District</Label>
          <Input
            type="text"
            id="district"
            name="district"
            value={formData.district}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="ifscCode">IFSC Code</Label>
          <Input
            type="text"
            id="ifscCode"
            name="ifscCode"
            value={formData.ifscCode}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="landArea">Land Area</Label>
          <Input
            type="text"
            id="landArea"
            name="landArea"
            value={formData.landArea}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="landmark">Landmark</Label>
          <Input
            type="text"
            id="landmark"
            name="landmark"
            value={formData.landmark}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="mainCrops">Main Crops</Label>
          <Input
            type="text"
            id="mainCrops"
            name="mainCrops"
            value={formData.mainCrops}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="name">Name</Label>
          <Input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            type="text"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="pincode">Pincode</Label>
          <Input
            type="text"
            id="pincode"
            name="pincode"
            value={formData.pincode}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="state">State</Label>
          <Input
            type="text"
            id="state"
            name="state"
            value={formData.state}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="tehsil">Tehsil</Label>
          <Input
            type="text"
            id="tehsil"
            name="tehsil"
            value={formData.tehsil}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="village">Village</Label>
          <Input
            type="text"
            id="village"
            name="village"
            value={formData.village}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="emitraGmailId">EMitra Gmail ID</Label>
          <Input
            type="email"
            id="emitraGmailId"
            name="emitraGmailId"
            value={formData.emitraGmailId}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label htmlFor="password">Password</Label>
          <Input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </FormGroup>

        <Button type="button" secondary onClick={handleVerify}>
          Verify
        </Button>
        <Button type="submit">Register Farmer</Button>
      </form>

      {popupVisible && (
        <>
          <Overlay onClick={closePopup} />
          <Popup>
            <p>{popupMessage}</p>
            <Button onClick={closePopup}>Close</Button>
          </Popup>
        </>
      )}
    </Container>
  );
};

export default FarmerRegistrationForm;
