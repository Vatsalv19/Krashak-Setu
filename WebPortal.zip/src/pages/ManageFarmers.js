
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getFirestore, collection, getDocs, deleteDoc, doc, setDoc, updateDoc, arrayRemove, arrayUnion, getDoc } from 'firebase/firestore';
import { TextField, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton, Box, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { Edit, Delete, Search as SearchIcon, Agriculture, Download } from '@mui/icons-material';
// import { jsPDF } from 'jspdf';
// import DownloadCard from './DownloadCard'; // Import the DownloadCard component

const ManageFarmers = () => {
    const [farmers, setFarmers] = useState([]);
    const [filteredFarmers, setFilteredFarmers] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [editingFarmer, setEditingFarmer] = useState(null);
    const [newFarmer, setNewFarmer] = useState({ name: '', village: '', contact: '', aadhar_no: '' });
    const [addDialogOpen, setAddDialogOpen] = useState(false);
    const { state } = useLocation();
    const { tehsilReference } = state || {}; 
    const db = getFirestore();

    useEffect(() => {
        if (!tehsilReference) return;

        const fetchFarmers = async () => {
            try {
                const farmersCollectionRef = collection(db, 'farmers');
                const farmersSnapshot = await getDocs(farmersCollectionRef);
                const farmerData = farmersSnapshot.docs
                    .map((doc) => ({ id: doc.id, ...doc.data() }))
                    .filter((farmer) => farmer.tehsilReference === tehsilReference);

                setFarmers(farmerData);
                setFilteredFarmers(farmerData);
            } catch (error) {
                console.error('Error fetching farmers:', error);
            }
        };

        fetchFarmers();
    }, [tehsilReference, db]);

    const handleSearch = (event) => {
        const query = event.target.value.toLowerCase();
        setSearchQuery(query);
        if (query) {
            const filtered = farmers.filter((farmer) =>
                farmer.name.toLowerCase().includes(query) || farmer.village.toLowerCase().includes(query)
            );
            setFilteredFarmers(filtered);
        } else {
            setFilteredFarmers(farmers);
        }
    };

    const handleDeleteFarmer = async (farmerId) => {
        try {
            const farmerRef = doc(db, 'farmers', farmerId);
            const farmerDoc = await getDoc(farmerRef);

            if (farmerDoc.exists()) {
                const { aadhar_no } = farmerDoc.data();

                // Remove farmer's aadhar_no from Tehsil
                const tehsilRef = doc(db, 'tehsils', tehsilReference);
                await updateDoc(tehsilRef, {
                    farmers: arrayRemove(aadhar_no),
                });

                // Delete the farmer's document
                await deleteDoc(farmerRef);

                // Update UI
                setFarmers((prev) => prev.filter((farmer) => farmer.id !== farmerId));
                setFilteredFarmers((prev) => prev.filter((farmer) => farmer.id !== farmerId));
            }
        } catch (error) {
            console.error('Error deleting farmer:', error);
        }
    };

    const handleEditFarmer = (farmer) => {
        setEditingFarmer(farmer);
    };

    const handleSaveEdit = async () => {
        try {
            const farmerRef = doc(db, 'farmers', editingFarmer.id);
            await updateDoc(farmerRef, editingFarmer);
            setFarmers((prev) =>
                prev.map((farmer) => (farmer.id === editingFarmer.id ? editingFarmer : farmer))
            );
            setFilteredFarmers((prev) =>
                prev.map((farmer) => (farmer.id === editingFarmer.id ? editingFarmer : farmer))
            );
            setEditingFarmer(null);
        } catch (error) {
            console.error('Error updating farmer:', error);
        }
    };

    const handleAddFarmer = async () => {
        try {
            const farmerRef = doc(collection(db, 'farmers'));
            await setDoc(farmerRef, { ...newFarmer, tehsilReference });

            const tehsilRef = doc(db, 'tehsils', tehsilReference);
            await updateDoc(tehsilRef, {
                farmers: arrayUnion(newFarmer.aadhar_no),
            });

            setFarmers((prev) => [...prev, { id: farmerRef.id, ...newFarmer }]);
            setFilteredFarmers((prev) => [...prev, { id: farmerRef.id, ...newFarmer }]);
            setAddDialogOpen(false);
            setNewFarmer({ name: '', village: '', contact: '', aadhar_no: '' });
        } catch (error) {
            console.error('Error adding farmer:', error);
        }
    };

    const generatePDF = (farmer) => {
        // const doc = new jsPDF();

        // Set the font size and add the title
        doc.setFontSize(20);
        doc.text('Government of India', 70, 20);

        // Add farmer's personal details
        doc.setFontSize(12);
        doc.text(`Name: ${farmer.name}`, 20, 40);
        doc.text(`Aadhar Number: ${farmer.aadhar_no}`, 20, 50);
        doc.text(`Contact: ${farmer.contact}`, 20, 60);
        doc.text(`Village: ${farmer.village}`, 20, 70);

        // Add any additional details (e.g., farm land details)
        if (farmer.farm_land) {
            doc.text(`Farm Land: ${farmer.farm_land}`, 20, 80);
        }

        // Save the PDF
        doc.save(`${farmer.name}_Farmer_Card.pdf`);
    };

    return (
        <Box sx={{ backgroundColor: '#f1f8e9', padding: 3, borderRadius: 2 }}>
            {/* Search Bar */}
            <Box sx={{ display: 'flex', alignItems: 'center', marginBottom: 3 }}>
                <SearchIcon sx={{ color: '#388e3c', marginRight: 1 }} />
                <TextField
                    label="Search Farmers"
                    variant="outlined"
                    fullWidth
                    value={searchQuery}
                    onChange={handleSearch}
                    sx={{ borderColor: '#388e3c', marginBottom: 2 }}
                    InputProps={{
                        style: { fontFamily: 'Arial, sans-serif', backgroundColor: '#fff3e0' },
                    }}
                />
            </Box>

            {/* Farmers Table */}
            <TableContainer component={Paper} sx={{ borderRadius: 2, boxShadow: 3 }}>
                <Table>
                    <TableHead sx={{ backgroundColor: '#81c784' }}>
                        <TableRow>
                            <TableCell sx={{ fontWeight: 'bold', color: '#fff' }}>Name</TableCell>
                            <TableCell sx={{ fontWeight: 'bold', color: '#fff' }}>Village</TableCell>
                            <TableCell sx={{ fontWeight: 'bold', color: '#fff' }}>Contact</TableCell>
                            <TableCell sx={{ fontWeight: 'bold', color: '#fff' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {filteredFarmers.map((farmer) => (
                            <TableRow key={farmer.id}>
                                <TableCell>{farmer.name}</TableCell>
                                <TableCell>{farmer.village}</TableCell>
                                <TableCell>{farmer.contact}</TableCell>
                                <TableCell>
                                    <IconButton onClick={() => handleEditFarmer(farmer)} sx={{ color: '#388e3c' }}>
                                        <Edit />
                                    </IconButton>
                                    <IconButton onClick={() => handleDeleteFarmer(farmer.id)} sx={{ color: '#d32f2f' }}>
                                        <Delete />
                                    </IconButton>
                                    <IconButton onClick={() => generatePDF(farmer)} sx={{ color: '#1976d2' }}>
                                        <Download />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            {/* Add Farmer Button */}
            <Box sx={{ marginTop: 3, textAlign: 'center' }}>
                <Button
                    variant="contained"
                    color="success"
                    onClick={() => setAddDialogOpen(true)}
                    sx={{
                        backgroundColor: '#388e3c',
                        '&:hover': { backgroundColor: '#2c6d2f' },
                        padding: '12px 24px',
                        fontWeight: 'bold',
                        borderRadius: 3,
                    }}
                    startIcon={<Agriculture />}
                >
                    Add New Farmer
                </Button>
            </Box>

            {/* Add Farmer Card */}
            {/* <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, justifyContent: 'center', marginTop: 3 }}>
                {filteredFarmers.map((farmer) => (
                    <DownloadCard key={farmer.id} farmer={farmer} />
                ))}
            </Box> */}

            {/* Edit Farmer Dialog */}
            <Dialog open={!!editingFarmer} onClose={() => setEditingFarmer(null)}>
                <DialogTitle>Edit Farmer</DialogTitle>
                <DialogContent>
                    <TextField
                        label="Name"
                        fullWidth
                        value={editingFarmer?.name || ''}
                        onChange={(e) => setEditingFarmer({ ...editingFarmer, name: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        label="Village"
                        fullWidth
                        value={editingFarmer?.village || ''}
                        onChange={(e) => setEditingFarmer({ ...editingFarmer, village: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        label="Contact"
                        fullWidth
                        value={editingFarmer?.contact || ''}
                        onChange={(e) => setEditingFarmer({ ...editingFarmer, contact: e.target.value })}
                        margin="normal"
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setEditingFarmer(null)}>Cancel</Button>
                    <Button onClick={handleSaveEdit} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Add Farmer Dialog */}
            <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)}>
                <DialogTitle>Add Farmer</DialogTitle>
                <DialogContent>
                    <TextField
                        label="Name"
                        fullWidth
                        value={newFarmer.name}
                        onChange={(e) => setNewFarmer({ ...newFarmer, name: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        label="Village"
                        fullWidth
                        value={newFarmer.village}
                        onChange={(e) => setNewFarmer({ ...newFarmer, village: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        label="Contact"
                        fullWidth
                        value={newFarmer.contact}
                        onChange={(e) => setNewFarmer({ ...newFarmer, contact: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        label="Aadhar Number"
                        fullWidth
                        value={newFarmer.aadhar_no}
                        onChange={(e) => setNewFarmer({ ...newFarmer, aadhar_no: e.target.value })}
                        margin="normal"
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setAddDialogOpen(false)}>Cancel</Button>
                    <Button onClick={handleAddFarmer} color="primary">
                        Add
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default ManageFarmers;
