import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from './UserContext'; // Import UserContext to access the login function
import Cookies from 'js-cookie'; // Import js-cookie

const EMitraLogin = () => {
  const [firstname, setFirstname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { login } = useUser(); // Get the login function from context

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the credentials
    if (
      firstname === 'Vatsal Shukla' &&
      email === 'vatsalshukla21@gmail.com' &&
      password === '1234'
    ) {
      // Call the login function to set user state (optional)
      login(email, password);

      // Save email in cookies for future use (expiration time can be adjusted as needed)
      Cookies.set('userEmail', email, { expires: 7 }); // Cookie will expire in 7 days

      // Navigate to the next page
      navigate('/EmitraPage');
    } else {
      alert('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className="container">
      <form className="form" onSubmit={handleSubmit}>
        <p className="title">E-Mitra Support</p>
        <p className="message">Signup now and get full access to our services.</p>

        <div className="flex">
          <label>
            <input
              required
              type="text"
              className="input"
              value={firstname}
              onChange={(e) => setFirstname(e.target.value)}
            />
            <span>Firstname</span>
          </label>
        </div>

        <label>
          <input
            required
            type="email"
            className="input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <span>Email</span>
        </label>

        <label>
          <input
            required
            type="password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <span>Password</span>
        </label>

        <button type="submit" className="submit">
          Submit
        </button>
      </form>
      <style>{`
        .container {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh; /* Take up the full height of the viewport */
        }

        .form {
          display: flex;
          flex-direction: column;
          gap: 15px; /* Increased gap between elements */
          max-width: 800px; /* Increased form width */
          width: 100%;
          background-color: #fff;
          padding: 30px; /* Increased padding for a bigger form */
          border-radius: 20px;
          position: relative;
          text-align: center;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Optional shadow for depth */
        }

        .title {
          font-size: 32px; /* Increased font size */
          color: royalblue;
          font-weight: 600;
          letter-spacing: -1px;
          position: relative;
          display: flex;
          align-items: center;
          padding-left: 30px;
        }

        .title::before, .title::after {
          position: absolute;
          content: "";
          height: 16px;
          width: 16px;
          border-radius: 50%;
          left: 0px;
          background-color: royalblue;
        }

        .title::before {
          width: 20px;
          height: 20px; /* Increased size of the circle */
          background-color: royalblue;
        }

        .title::after {
          width: 20px;
          height: 20px; /* Increased size of the circle */
          animation: pulse 1s linear infinite;
        }

        .message, .signin {
          color: rgba(88, 87, 87, 0.822);
          font-size: 16px; /* Slightly increased font size */
        }

        .signin {
          text-align: center;
        }

        .signin a {
          color: royalblue;
        }

        .signin a:hover {
          text-decoration: underline royalblue;
        }

        .flex {
          display: flex;
          width: 100%;
          gap: 12px; /* Increased gap between first and last name inputs */
        }

        .form label {
          position: relative;
          width: 100%;
        }

        .form label .input {
          width: 100%;
          padding: 12px 12px 25px 12px; /* Increased padding for bigger input fields */
          outline: 0;
          border: 1px solid rgba(105, 105, 105, 0.397);
          border-radius: 12px; /* Slightly larger border radius */
          font-size: 16px; /* Increased font size */
        }

        .form label .input + span {
          position: absolute;
          left: 12px; /* Adjusted positioning */
          top: 20px; /* Adjusted positioning */
          color: grey;
          font-size: 1em; /* Adjusted font size */
          cursor: text;
          transition: 0.3s ease;
        }

        .form label .input:placeholder-shown + span {
          top: 20px; /* Adjusted positioning */
          font-size: 1em; /* Adjusted font size */
        }

        .form label .input:focus + span, .form label .input:valid + span {
          top: 35px; /* Adjusted positioning */
          font-size: 0.8em;
          font-weight: 600;
        }

        .form label .input:valid + span {
          color: green;
        }

        .submit {
          border: none;
          outline: none;
          background-color: royalblue;
          padding: 15px; /* Increased padding */
          border-radius: 12px; /* Slightly larger border radius */
          color: #fff;
          font-size: 18px; /* Increased font size */
          cursor: pointer;
          transform: 0.3s ease;
        }

        .submit:hover {
          background-color: rgb(56, 90, 194);
        }

        @keyframes pulse {
          from {
            transform: scale(0.9);
            opacity: 1;
          }

          to {
            transform: scale(1.8);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};

export default EMitraLogin;
