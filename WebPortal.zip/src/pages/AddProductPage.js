import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCookies } from 'react-cookie'; // Import useCookies to get the cookie
import styled from 'styled-components';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from './firebase';
import { doc, collection, addDoc } from 'firebase/firestore';
import Sliderbar from '../components/Sliderbar';

// Styled Components
const PageContainer = styled.div`
  display: flex;
  flex-direction: row;
  min-height: 100vh;
  background-color: #f9f9f9;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const ContentContainer = styled.div`
  flex: 1;
  padding: 20px;
  max-width: 800px;
  margin: 50px auto;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

const FormTitle = styled.h2`
  margin-bottom: 20px;
  text-align: center;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border-radius: 4px;
  border: 1px solid #ccc;
`;

const Button = styled.button`
  padding: 10px 20px;
  background-color: #228B22;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 10px;
  &:hover {
    background-color: #1c6d1c;
  }
`;

const Loading = styled.div`
  text-align: center;
  margin-top: 20px;
`;

const SuccessMessage = styled.div`
  margin-top: 20px;
  color: green;
  text-align: center;
`;

const AddProductPage = () => {
  const [cookies] = useCookies(['aadhar']); // Get Aadhar from cookies
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    description: '',
    price: '',
    quantity: '',
    address: '',
    farmerName: '',
    image: null,
    harvestDate: '', // New field for harvest date
    listingTime: '', // New field for listing time (auto-populated)
    negotiablePrice: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  const aadhar = cookies.aadhar; // Retrieve Aadhar from cookie
  if (!aadhar) {
    return <Loading>Please log in with your Aadhar to add a product.</Loading>;
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      image: e.target.files[0],
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    let imageurl = '';

    try {
      // Validate Aadhar
      const aadhar = cookies.aadhar ? String(cookies.aadhar).trim() : null;
      if (!aadhar || typeof aadhar !== 'string' || aadhar === '') {
        throw new Error('Aadhar number is invalid or missing');
      }

      // Upload image to Firebase Storage (if present)
      if (formData.image) {
        const storageRef = ref(storage, `productImages/${formData.image.name}`);
        await uploadBytes(storageRef, formData.image);
        imageurl = await getDownloadURL(storageRef);
      }

      // Set listing time as the current time
      const listingTime = new Date().toISOString();

      // Prepare product data
      const productData = {
        name: formData.name,
        category: formData.category,
        description: formData.description,
        price: formData.price,
        quantity: formData.quantity,
        address: formData.address,
        farmerName: formData.farmerName,
        harvestDate: formData.harvestDate, // Harvest date from user input
        listingTime: listingTime, // Listing time set automatically
        aadhar: aadhar,
        imageurl: imageurl || null,
        negotiablePrice:formData.negotiablePrice
      };

      // Add product data to 'products' subcollection under the Aadhar document in 'crops_data'
      const aadharDocRef = doc(db, 'crops_data', aadhar);
      const productCollectionRef = collection(aadharDocRef, 'products'); // Subcollection for products
      await addDoc(productCollectionRef, productData);

      // Add the same product data to the 'crops' collection with an auto-generated document ID
      const cropsCollectionRef = collection(db, 'crops'); // Main collection for all crops
      await addDoc(cropsCollectionRef, productData);

      // Success feedback
      setSuccessMessage('Product added successfully!');
      setFormData({
        name: '',
        category: '',
        description: '',
        price: '',
        quantity: '',
        address: '',
        farmerName: '',
        image: null,
        harvestDate: '', // Reset harvest date
        listingTime: '', // Reset listing time
        negotiablePrice:''
      });
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Product submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageContainer>
      <Sliderbar />
      <ContentContainer>
        <FormTitle>Add New Product</FormTitle>
        <form onSubmit={handleSubmit}>
          <FormGroup>
            <Label htmlFor="farmerName">Farmer Name</Label>
            <Input
              type="text"
              id="farmerName"
              name="farmerName"
              value={formData.farmerName}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="address">Address</Label>
            <Input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="name">Product Name</Label>
            <Input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="category">Category</Label>
            <Input
              type="text"
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="description">Product Description</Label>
            <Input
              type="text"
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="price">Price</Label>
            <Input
              type="number"
              id="price"
              name="price"
              value={formData.price}
              onChange={handleChange}
              required
            />
          </FormGroup>


          <FormGroup>
  <Label htmlFor="negotiablePrice">Negotiable Price</Label>
  <Input
    type="number"
    id="negotiablePrice"
    name="negotiablePrice"  // Corrected name attribute
    value={formData.negotiablePrice}
    onChange={handleChange}
    required
  />
</FormGroup>


          <FormGroup>
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              type="number"
              id="quantity"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="harvestDate">Harvest Date</Label>
            <Input
              type="date"
              id="harvestDate"
              name="harvestDate"
              value={formData.harvestDate}
              onChange={handleChange}
              required
            />
          </FormGroup>

          <FormGroup>
            <Label htmlFor="image">Upload Image</Label>
            <Input
              type="file"
              id="image"
              name="image"
              accept="image/*"
              onChange={handleFileChange}
            />
          </FormGroup>

          <Button type="submit" disabled={submitting}>
            {submitting ? 'Submitting...' : 'Submit'}
          </Button>
        </form>

        {successMessage && <SuccessMessage>{successMessage}</SuccessMessage>}
      </ContentContainer>
    </PageContainer>
  );
};

export default AddProductPage;
