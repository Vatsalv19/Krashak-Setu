import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
  padding: 20px;
  max-width: 400px;
  margin: 0 auto;
`;

const GovernmentServicesLogin = () => {
  return (
    <Container>
      <h2>Government Services Login</h2>
      <form>
        <label>Service ID:</label>
        <input type="text" placeholder="Enter Service ID" />
        
        <label>Password:</label>
        <input type="password" placeholder="Enter password" />
        
        <button type="submit">Login</button>
      </form>
    </Container>
  );
};

export default GovernmentServicesLogin;
