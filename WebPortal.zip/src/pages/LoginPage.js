import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

// Container for the entire page
const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%); // Gradient background
  font-family: 'Roboto', sans-serif;
`;

// Content wrapper
const ContentWrapper = styled.div`
  text-align: center;
  padding: 40px;
  border-radius: 10px;
  background-color: #ffffff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 600px;
`;

// Heading
const Heading = styled.h2`
  font-size: 3rem;
  color: #333;
  margin-bottom: 20px;
  font-weight: 700;
`;

// Subheading
const Subheading = styled.p`
  font-size: 1.3rem;
  color: #555;
  margin-bottom: 40px;
`;

// Button styling
const Button = styled(Link)`
  display: inline-block;
  margin: 20px 0;
  padding: 15px 30px;
  background-color: #2980b9;
  color: white;
  font-size: 1.2rem;
  font-weight: bold;
  border-radius: 8px;
  text-decoration: none;
  text-align: center;
  transition: background-color 0.3s ease, transform 0.2s ease;
  
  &:hover {
    background-color: #3498db;
    transform: scale(1.05);
  }

  &:active {
    background-color: #2980b9;
    transform: scale(1);
  }
`;

// LoginPage Component
const LoginPage = () => {
  return (
    <Container>
      <ContentWrapper>
        <Heading>Welcome to the Login Portal</Heading>
        <Subheading>Select a service to log in:</Subheading>
        <Button to="/emitra-login">E-mitra Login</Button>
        <Button to="/gov-services-login">Government Services Login</Button>
      </ContentWrapper>
    </Container>
  );
};

export default LoginPage;
