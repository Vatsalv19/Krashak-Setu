import React, { useEffect, useState } from 'react';
import { useUser } from './UserContext';
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Link } from 'react-router-dom';
import { FiHome, FiUser, FiShoppingCart, FiBook, FiLogOut } from 'react-icons/fi';
import styled, { keyframes } from 'styled-components';

// Slide-in animation for Sidebar
const slideIn = keyframes`
  from {
    transform: translateX(-100%);
  }
  to {
    transform: translateX(0);
  }
`;

// Fade-in animation for cards
const fadeIn = keyframes`
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;

const Sidebar = styled.div`
  width: 250px;
  background-color: #1e272e;
  color: white;
  padding: 20px;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  z-index: 100;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.3);
  animation: ${slideIn} 0.8s ease-out;

  h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 20px;
    font-weight: bold;
    color: #f39c12;
  }

  @media (max-width: 768px) {
    flex-direction: row;
    justify-content: space-around;
    width: 100%;
    position: relative;
    height: auto;
    padding: 10px;
    box-shadow: none;
    h2 {
      display: none; /* Hide the title on small screens */
    }
  }
`;

const SidebarItem = styled.div`
  display: flex;
  align-items: center;
  margin: 15px 0;
  cursor: pointer;
  padding: 12px;
  border-radius: 8px;
  transition: background 0.3s ease-in-out, transform 0.2s ease;

  &:hover {
    background-color: #34495e;
    transform: scale(1.05);
  }

  @media (max-width: 768px) {
    margin: 5px 0;
    justify-content: center;
    flex-direction: column;
  }
`;

const SidebarIcon = styled.div`
  font-size: 1.6rem;
  margin-right: 10px;

  @media (max-width: 768px) {
    margin-right: 0;
  }
`;

const SidebarLink = styled(Link)`
  color: white;
  text-decoration: none;
  font-size: 1.1rem;

  @media (max-width: 768px) {
    font-size: 0.9rem;
  }
`;

const ProfileContainer = styled.div`
  margin-left: 260px;
  padding: 20px;
  width: 100%;
  background-color: #ecf0f1;
  min-height: 100vh;
  font-family: 'Poppins', sans-serif;

  @media (max-width: 768px) {
    margin-left: 0;
    padding: 15px;
  }
`;

const ProfileTitle = styled.h1`
  font-size: 2.8rem;
  color: #2c3e50;
  text-align: center;
  margin-bottom: 30px;
  animation: ${fadeIn} 1s ease-out;

  @media (max-width: 768px) {
    font-size: 2rem;
    margin-bottom: 20px;
  }
`;

const ProfileCard = styled.div`
  background-color: #ffffff;
  padding: 40px;
  border-radius: 15px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  margin: auto;
  text-align: left;
  transition: transform 0.4s ease, box-shadow 0.4s ease;
  animation: ${fadeIn} 1.2s ease-out;

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
  }

  @media (max-width: 768px) {
    padding: 20px;
    max-width: 90%;
  }
`;

const ProfileInfo = styled.p`
  font-size: 1.4rem;
  color: #34495e;
  margin-bottom: 30px; 

  strong {
    color: #2980b9;
  }

  @media (max-width: 768px) {
    font-size: 1.2rem;
    margin-bottom: 20px; 
  }
`;


const Message = styled.div`
  text-align: center;
  font-size: 1.6rem;
  color: ${(props) => (props.error ? '#e74c3c' : '#27ae60')};
  padding: 30px;

  @media (max-width: 768px) {
    font-size: 1.2rem;
    padding: 15px;
  }
`;

const ProfilePage = () => {
  const { user } = useUser();
  const [farmerDetails, setFarmerDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFarmerDetails = async () => {
      if (user && user.aadhar) {
        try {
          const farmerDocRef = doc(db, 'farmer_data', user.aadhar);
          const farmerDoc = await getDoc(farmerDocRef);

          if (farmerDoc.exists()) {
            setFarmerDetails(farmerDoc.data());
          }
        } catch (error) {
          console.error('Error fetching farmer details:', error);
        } finally {
          setLoading(false);
        }
      } else {
        setLoading(false);
      }
    };

    fetchFarmerDetails();
  }, [user]);

  if (loading) {
    return <Message>Loading farmer profile...</Message>;
  }

  if (!user || !farmerDetails) {
    return <Message error>Please log in or ensure your profile is set up.</Message>;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'stretch' }}>
      <Sidebar>
        <h2>Farmers Portal</h2>
        <SidebarItem>
          <SidebarIcon>
            <FiHome />
          </SidebarIcon>
          <SidebarLink to="/FarmerDashboard">Home</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiUser />
          </SidebarIcon>
          <SidebarLink to="/profile">Profile</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiShoppingCart />
          </SidebarIcon>
          <SidebarLink to="/products">Listed Crops</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiBook />
          </SidebarIcon>
          <SidebarLink to="/TopProduct">Resources</SidebarLink>
        </SidebarItem>
        <SidebarItem>
          <SidebarIcon>
            <FiLogOut />
          </SidebarIcon>
          <SidebarLink to="/logout">Log Out</SidebarLink>
        </SidebarItem>
      </Sidebar>

      <ProfileContainer>
        <ProfileTitle>Farmer Profile</ProfileTitle>
        <ProfileCard>
          <ProfileInfo>
            <strong>Name:</strong> {farmerDetails.name || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Aadhar:</strong> {user.aadhar}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Phone:</strong> {farmerDetails.phone || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Address:</strong> {farmerDetails.address || 'Not provided'}
            <ProfileInfo><br />
            <strong>State:</strong> {farmerDetails.state || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Village:</strong> {farmerDetails.village || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Tehsil:</strong> {farmerDetails.tehsil || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Pincode:</strong> {farmerDetails.pincode || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Landmark:</strong> {farmerDetails.landmark || 'Not provided'}
          </ProfileInfo>
          <ProfileInfo>
            <strong>Main Crops:</strong> {farmerDetails.mainCrops || 'Not provided'}
          </ProfileInfo>
          </ProfileInfo>
        </ProfileCard>
      </ProfileContainer>
    </div>
  );
};

export default ProfilePage;
